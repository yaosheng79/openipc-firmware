/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2018-2020. All rights reserved.
 * Description: Linux ioctl configuration command.
 * Author: Hisilicon
 * Create: 2018-08-04
 */

/*****************************************************************************
  1 ͷ�ļ�����
*****************************************************************************/
#include "oal_ext_if.h"
#include "oam_ext_if.h"
#include "hmac_ext_if.h"
#include "wal_main.h"
#include "wal_ioctl.h"
#include "wal_event_msg.h"
#include "wal_hipriv.h"
#include "wal_net.h"
#include "wal_11d.h"

#include "wal_customize.h"

#if (_PRE_MULTI_CORE_MODE_OFFLOAD_DMAC == _PRE_MULTI_CORE_MODE)
#endif

#if (_PRE_OS_VERSION_LITEOS == _PRE_OS_VERSION)
#include "lwip/netifapi.h"
#endif
#ifdef _PRE_WLAN_FEATURE_ANY
#include "hi_any_api.h"
#endif

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define MAX_PRIV_CMD_SIZE   4096

/*****************************************************************************
  ˽���������. ˽�������ʽ:
         �豸�� ������ ����
  hipriv "Hisilicon0 create vap0"
*****************************************************************************/
/* Android private command strings */
#define CMD_SET_AP_WPS_P2P_IE   "SET_AP_WPS_P2P_IE"
#define CMD_P2P_SET_NOA         "P2P_SET_NOA"
#define CMD_P2P_SET_PS          "P2P_SET_PS"
#define CMD_SET_POWER_ON        "SET_POWER_ON"
#define CMD_SET_POWER_MGMT_ON   "SET_POWER_MGMT_ON"
#define CMD_COUNTRY             "COUNTRY"
#define CMD_SET_QOS_MAP         "SET_QOS_MAP"
#define CMD_TX_POWER            "TX_POWER"
#define CMD_WPAS_GET_CUST       "WPAS_GET_CUST"
#define CMD_SET_SSID            "SET_SSID"

/*****************************************************************************
  �ṹ�嶨��
*****************************************************************************/
#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
typedef struct {
    hi_u32   ap_max_user;                      /* ap����û��� */
    hi_char  ac_ap_mac_filter_mode[257];          /* AP mac��ַ�����������,�257 */
    hi_s32   ap_power_flag;                     /* AP�ϵ��־ */
}wal_ap_config_stru;
#endif /* #if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION) */

/*****************************************************************************
  2 ��������
*****************************************************************************/
/* ��̬�������� */
#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static hi_u32 wal_ioctl_get_mode(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_get_essid(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_get_bss_type(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_set_bss_type(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_get_freq(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_get_txpower(oal_net_device_stru *netdev, hi_s8 *pc_param);
static hi_u32 wal_ioctl_get_apaddr(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                   oal_sockaddr_stru *addr, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_iwrate(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                   oal_iw_param_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_iwsense(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                    oal_iw_param_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_rtsthres(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                     oal_iw_param_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_fragthres(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                      oal_iw_param_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_iwencode(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                     oal_iw_point_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_iwrange(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                    oal_iw_point_stru *param, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_param(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                  hi_void *iw, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_set_param(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                  hi_void *iw, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_iwname(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                   hi_s8* pc_name, hi_s8* pc_extra);
static hi_s32 wal_ioctl_set_wme_params(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                       hi_void *iw, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_get_wme_params(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                       hi_void *iw, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_setcountry(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                   hi_void *w, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_getcountry(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                   hi_void *w, hi_s8 *pc_extra);
static hi_u32 wal_ioctl_reduce_sar(oal_net_device_stru *netdev, hi_u8 tx_power);
static hi_s32 wal_ioctl_set_ap_config(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                      oal_iwreq_data_union *wrqu, hi_s8 *pc_extra);
static hi_s32 wal_ioctl_get_assoc_list(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                       oal_iwreq_data_union *wrqu, hi_s8 *pc_extra);
static hi_s32 wal_ioctl_set_mac_filters(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                        oal_iwreq_data_union *wrqu, hi_s8 *pc_extra);
static hi_s32 wal_ioctl_set_ap_sta_disassoc(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                            oal_iwreq_data_union *wrqu, hi_s8 *pc_extra);
#endif

/*****************************************************************************
  2 ȫ�ֱ�������
*****************************************************************************/
#if (_PRE_MULTI_CORE_MODE_OFFLOAD_DMAC == _PRE_MULTI_CORE_MODE) && (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
/* DTS2016012602459 ��֧��ethtool_ops ��غ�������,��Ҫ��ʾ����յĽṹ�壬
   ���򽫲����ں�Ĭ�ϵ�ethtool_ops�ᵼ�¿�ָ���쳣 */
oal_ethtool_ops_stru g_wal_ethtool_ops = { 0 };
#endif

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static wal_ap_config_stru g_st_ap_config_info = {0};    /* AP������Ϣ,��Ҫ��vap �������·��� */

/*****************************************************************************
  ��׼ioctl�������.
*****************************************************************************/
static const oal_iw_handler g_ast_iw_handlers[] = {
    HI_NULL,                               /* SIOCSIWCOMMIT, */
    (oal_iw_handler)wal_ioctl_get_iwname,       /* SIOCGIWNAME, */
    HI_NULL,                               /* SIOCSIWNWID, */
    HI_NULL,                               /* SIOCGIWNWID, */
    (oal_iw_handler)wal_ioctl_set_freq,         /* SIOCSIWFREQ, ����Ƶ��/�ŵ� */
    (oal_iw_handler)wal_ioctl_get_freq,         /* SIOCGIWFREQ, ��ȡƵ��/�ŵ� */
    (oal_iw_handler)wal_ioctl_set_bss_type,     /* SIOCSIWMODE, ����bss type */
    (oal_iw_handler)wal_ioctl_get_bss_type,     /* SIOCGIWMODE, ��ȡbss type */
    HI_NULL,                               /* SIOCSIWSENS, */
    (oal_iw_handler)wal_ioctl_get_iwsense,      /* SIOCGIWSENS, */
    HI_NULL,                               /* SIOCSIWRANGE, */ /* not used */
    (oal_iw_handler)wal_ioctl_get_iwrange,      /* SIOCGIWRANGE, */
    HI_NULL,                               /* SIOCSIWPRIV, */  /* not used */
    HI_NULL,                               /* SIOCGIWPRIV, */  /* kernel code */
    HI_NULL,                               /* SIOCSIWSTATS, */ /* not used */
    HI_NULL,                               /* SIOCGIWSTATS, */
    HI_NULL,                               /* SIOCSIWSPY, */
    HI_NULL,                               /* SIOCGIWSPY, */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* SIOCSIWAP, */
    (oal_iw_handler)wal_ioctl_get_apaddr,       /* SIOCGIWAP, */
    HI_NULL,                               /* SIOCSIWMLME, */
    HI_NULL,                               /* SIOCGIWAPLIST, */
    HI_NULL,                               /* SIOCSIWSCAN, */
    HI_NULL,                               /* SIOCGIWSCAN, */
    (oal_iw_handler)wal_ioctl_set_essid,        /* SIOCSIWESSID, ����ssid */
    (oal_iw_handler)wal_ioctl_get_essid,        /* SIOCGIWESSID, ��ȡssid */
    HI_NULL,                               /* SIOCSIWNICKN */
    HI_NULL,                               /* SIOCGIWNICKN */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* SIOCSIWRATE */
    (oal_iw_handler)wal_ioctl_get_iwrate,       /* SIOCGIWRATE */
    HI_NULL,                               /* SIOCSIWRTS */
    (oal_iw_handler)wal_ioctl_get_rtsthres,     /* SIOCGIWRTS */
    HI_NULL,                               /* SIOCSIWFRAG */
    (oal_iw_handler)wal_ioctl_get_fragthres,    /* SIOCGIWFRAG */
    (oal_iw_handler)wal_ioctl_set_txpower,      /* SIOCSIWTXPOW, ���ô��书������ */
    (oal_iw_handler)wal_ioctl_get_txpower,      /* SIOCGIWTXPOW, ���ô��书������ */
    HI_NULL,                               /* SIOCSIWRETRY */
    HI_NULL,                               /* SIOCGIWRETRY */
    HI_NULL,                               /* SIOCSIWENCODE */
    (oal_iw_handler)wal_ioctl_get_iwencode,     /* SIOCGIWENCODE */
    HI_NULL,                               /* SIOCSIWPOWER */
    HI_NULL,                               /* SIOCGIWPOWER */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* -- hole -- */
    HI_NULL,                               /* SIOCSIWGENIE */
    HI_NULL,                               /* SIOCGIWGENIE */
    HI_NULL,                               /* SIOCSIWAUTH */
    HI_NULL,                               /* SIOCGIWAUTH */
    HI_NULL,                               /* SIOCSIWENCODEEXT */
    HI_NULL                                /* SIOCGIWENCODEEXT */
};

/*****************************************************************************
  ˽��ioctl����������嶨��
*****************************************************************************/
static const oal_iw_priv_args_stru g_ast_iw_priv_args[] = {
    {WAL_IOCTL_PRIV_SET_MODE,       OAL_IW_PRIV_TYPE_CHAR | 24, 0, "mode"},     /* ����������char, ����Ϊ24 */
    {WAL_IOCTL_PRIV_GET_MODE,       0, OAL_IW_PRIV_TYPE_CHAR | 24, "get_mode"}, /* ����������char, ����Ϊ24 */
    {WAL_IOCTL_PRIV_SET_COUNTRY,    OAL_IW_PRIV_TYPE_CHAR | 3, 0,  "setcountry"}, /* ����������char, ����Ϊ3 */
    {WAL_IOCTL_PRIV_GET_COUNTRY,    0, OAL_IW_PRIV_TYPE_CHAR | 3,  "getcountry"}, /* ����������char, ����Ϊ3 */

    {WAL_IOCTL_PRIV_SET_AP_CFG, OAL_IW_PRIV_TYPE_CHAR |  256, 0, "AP_SET_CFG"}, /* ����������char, ����Ϊ256 */
    {WAL_IOCTL_PRIV_AP_MAC_FLTR, OAL_IW_PRIV_TYPE_CHAR | 256,                    /* ����������char, ����Ϊ256 */
     OAL_IW_PRIV_TYPE_CHAR | OAL_IW_PRIV_SIZE_FIXED | 0, "AP_SET_MAC_FLTR"},
    {WAL_IOCTL_PRIV_AP_GET_STA_LIST, 0, OAL_IW_PRIV_TYPE_CHAR | 1024, "AP_GET_STA_LIST"}, /* ����Ϊ1024 */
    {WAL_IOCTL_PRIV_AP_STA_DISASSOC, OAL_IW_PRIV_TYPE_CHAR | 256,                         /* ����Ϊ256 */
     OAL_IW_PRIV_TYPE_CHAR | 0, "AP_STA_DISASSOC"},

    /* sub-ioctl������� */
    {WAL_IOCTL_PRIV_SETPARAM,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,    /* ����Ϊ2 */
     0, "setparam"},
    {WAL_IOCTL_PRIV_GETPARAM,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
                                    OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "getparam"},

    /* sub-ioctl��־��nameΪ'\0', ����1��ʾset��������1������, get����õ�1��ֵ */
    {WAL_IOCTL_PRIV_SETPARAM,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, ""},
    {WAL_IOCTL_PRIV_SETPARAM,       OAL_IW_PRIV_TYPE_BYTE | OAL_IW_PRIV_SIZE_FIXED | OAL_IW_PRIV_TYPE_ADDR, 0, ""},
    {WAL_IOCTL_PRIV_GETPARAM,       0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, ""},
    {WAL_IOCTL_PRIV_GETPARAM,       0, OAL_IW_PRIV_TYPE_BYTE | OAL_IW_PRIV_SIZE_FIXED | OAL_IW_PRIV_TYPE_ADDR, ""},
    {WLAN_CFGID_SHORTGI,            OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "shortgi20"},
    {WLAN_CFGID_SHORTGI,            0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_shortgi20"},
    {WLAN_CFGID_SHORT_PREAMBLE,     OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "shpreamble"},
    {WLAN_CFGID_SHORT_PREAMBLE,     0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_shpreamble"},
    {WLAN_CFGID_PROT_MODE,          OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "protmode"},
    {WLAN_CFGID_PROT_MODE,          0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_protmode"},
    {WLAN_CFGID_AUTH_MODE,          OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "authmode"},
    {WLAN_CFGID_AUTH_MODE,          0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_authmode"},
    {WLAN_CFGID_BEACON_INTERVAL,    OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "bintval"},
    {WLAN_CFGID_BEACON_INTERVAL,    0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_bintval"},
    {WLAN_CFGID_TID,                0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_tid"},
    /* U-APSD���� */
    {WLAN_CFGID_UAPSD_EN,          OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "uapsden"},
    {WLAN_CFGID_UAPSD_EN,           0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_uapsden"},
    {WLAN_CFGID_DTIM_PERIOD,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, 0, "dtim_period"},
    {WLAN_CFGID_DTIM_PERIOD,        0, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_dtim_period"},

    /* EDCA������������ sub-ioctl��� */
    {WAL_IOCTL_PRIV_SET_WMM_PARAM, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 3, 0, "setwmmparam"}, /* ����Ϊ3 */
    {WAL_IOCTL_PRIV_GET_WMM_PARAM, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,                    /* ����Ϊ2 */
                                   OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, "getwmmparam"},   /* ����Ϊ2 */

    /* sub-ioctl��־��nameΪ'\0', 2��ʾset�������������� */
    {WAL_IOCTL_PRIV_SET_WMM_PARAM,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, ""},    /* ����Ϊ2 */
    {WAL_IOCTL_PRIV_GET_WMM_PARAM,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
                                         OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, ""},
    {WLAN_CFGID_EDCA_TABLE_CWMIN,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "cwmin"}, /* ����Ϊ2 */
    {WLAN_CFGID_EDCA_TABLE_CWMIN,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_cwmin"},
    {WLAN_CFGID_EDCA_TABLE_CWMAX,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "cwmax"}, /* ����Ϊ2 */
    {WLAN_CFGID_EDCA_TABLE_CWMAX,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_cwmax"},
    {WLAN_CFGID_EDCA_TABLE_AIFSN,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "aifsn"}, /* ����Ϊ2 */
    {WLAN_CFGID_EDCA_TABLE_AIFSN,        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_aifsn"},
    {WLAN_CFGID_EDCA_TABLE_TXOP_LIMIT, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "txoplimit"}, /* ����Ϊ2 */
    {WLAN_CFGID_EDCA_TABLE_TXOP_LIMIT,       OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_txoplimit"},
    {WLAN_CFGID_EDCA_TABLE_MSDU_LIFETIME, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,             /* ����Ϊ2 */
        0, "lifetime"},
    {WLAN_CFGID_EDCA_TABLE_MSDU_LIFETIME,    OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_lifetime"},
    {WLAN_CFGID_EDCA_TABLE_MANDATORY, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "mandatory"}, /* ����Ϊ2 */
    {WLAN_CFGID_EDCA_TABLE_MANDATORY, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_mandatory"},

    {WLAN_CFGID_QEDCA_TABLE_CWMIN, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "qcwmin"},   /* ����Ϊ2 */
    {WLAN_CFGID_QEDCA_TABLE_CWMIN, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qcwmin"},
    {WLAN_CFGID_QEDCA_TABLE_CWMAX, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "qcwmax"},  /* ����Ϊ2 */
    {WLAN_CFGID_QEDCA_TABLE_CWMAX, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qcwmax"},
    {WLAN_CFGID_QEDCA_TABLE_AIFSN, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2, 0, "qaifsn"},   /* ����Ϊ2 */
    {WLAN_CFGID_QEDCA_TABLE_AIFSN, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qaifsn"},
    {WLAN_CFGID_QEDCA_TABLE_TXOP_LIMIT, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,            /* ����Ϊ2 */
        0, "qtxoplimit"},
    {WLAN_CFGID_QEDCA_TABLE_TXOP_LIMIT, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qtxoplimit"},
    {WLAN_CFGID_QEDCA_TABLE_MSDU_LIFETIME, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,         /* ����Ϊ2 */
        0, "qlifetime"},
    {WLAN_CFGID_QEDCA_TABLE_MSDU_LIFETIME,    OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qlifetime"},
    {WLAN_CFGID_QEDCA_TABLE_MANDATORY, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 2,            /* ����Ϊ2 */
        0, "qmandatory"},
    {WLAN_CFGID_QEDCA_TABLE_MANDATORY, OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1,
        OAL_IW_PRIV_TYPE_INT | OAL_IW_PRIV_SIZE_FIXED | 1, "get_qmandatory"},

};

/*****************************************************************************
  ˽��ioctl�������.
*****************************************************************************/
static const oal_iw_handler g_ast_iw_priv_handlers[] = {
    (oal_iw_handler)wal_ioctl_set_param,           /* SIOCWFIRSTPRIV+0 */  /* sub-ioctl set ��� */
    (oal_iw_handler)wal_ioctl_get_param,           /* SIOCWFIRSTPRIV+1 */  /* sub-ioctl get ��� */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+2 */  /* setkey */
    (oal_iw_handler)wal_ioctl_set_wme_params,      /* SIOCWFIRSTPRIV+3 */  /* setwmmparams */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+4 */  /* delkey */
    (oal_iw_handler)wal_ioctl_get_wme_params,      /* SIOCWFIRSTPRIV+5 */  /* getwmmparams */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+6 */  /* setmlme */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+7 */  /* getchaninfo */
    (oal_iw_handler)wal_ioctl_setcountry,          /* SIOCWFIRSTPRIV+8 */  /* setcountry */
    (oal_iw_handler)wal_ioctl_getcountry,          /* SIOCWFIRSTPRIV+9 */  /* getcountry */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+10 */  /* addmac */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+11 */  /* getscanresults */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+12 */  /* delmac */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+13 */  /* getchanlist */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+14 */  /* setchanlist */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+15 */  /* kickmac */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+16 */  /* chanswitch */
    (oal_iw_handler)wal_ioctl_get_mode,            /* SIOCWFIRSTPRIV+17 */  /* ��ȡģʽ, ��: iwpriv vapN get_mode */
    (oal_iw_handler)wal_ioctl_set_mode,            /* SIOCWFIRSTPRIV+18 */  /* ����ģʽ, ��: iwpriv vapN mode 11g */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+19 */  /* getappiebuf */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+20 */  /* null */
    (oal_iw_handler)wal_ioctl_get_assoc_list,      /* SIOCWFIRSTPRIV+21 */  /* APUTȡ�ù���STA�б� */
    (oal_iw_handler)wal_ioctl_set_mac_filters,     /* SIOCWFIRSTPRIV+22 */  /* APUT����STA���� */
    (oal_iw_handler)wal_ioctl_set_ap_config,       /* SIOCWFIRSTPRIV+23 */  /* ����APUT���� */
    (oal_iw_handler)wal_ioctl_set_ap_sta_disassoc, /* SIOCWFIRSTPRIV+24 */  /* APUTȥ����STA */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+25 */  /* getStatistics */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+26 */  /* sendmgmt */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+27 */  /* null  */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+28 */  /* null */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+29 */  /* getaclmac */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+30 */  /* sethbrparams */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+29 */  /* getaclmac */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+30 */  /* sethbrparams */
    HI_NULL,                                       /* SIOCWFIRSTPRIV+31 */  /* setrxtimeout */
};
#endif

/*****************************************************************************
  Э��ģʽ�ַ�������
*****************************************************************************/
const wal_ioctl_mode_map_stru g_ast_mode_map[] = {
    {"11b",         WLAN_LEGACY_11B_MODE,       WLAN_BAND_2G,   WLAN_BAND_WIDTH_20M, {0}},
    {"11bg",        WLAN_MIXED_ONE_11G_MODE,    WLAN_BAND_2G,   WLAN_BAND_WIDTH_20M, {0}},
    {"11bgn",       WLAN_HT_MODE,               WLAN_BAND_2G,   WLAN_BAND_WIDTH_20M, {0}},
    {HI_NULL, 0, 0, 0, {0}}
};

/*****************************************************************************
 �� �� ��  : wal_get_cmd_one_arg
 ��������  : ��ȡ�ַ�����һ������ �Կո�Ϊ�������ֱ�ʶ
 �������  : pc_cmd         : ������ַ���
 �������  : pc_arg         : ��һ������
             pul_cmd_offset : ��һ�������ĳ���
 �� �� ֵ  : ������

 �޸���ʷ      :
  1.��    ��   : 2012��12��13��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_get_cmd_one_arg(const hi_char *pc_cmd, hi_char *pc_arg, hi_u32 pc_arg_len, hi_u32 *pul_cmd_offset)
{
    const hi_char *pc_cmd_copy = HI_NULL;
    hi_u32   pos = 0;

    if (oal_unlikely((pc_cmd == HI_NULL) || (pc_arg == HI_NULL) || (pul_cmd_offset == HI_NULL))) {
        oam_error_log3(0, 0,
            "{wal_get_cmd_one_arg::pc_cmd/pc_arg/pul_cmd_offset null ptr error %p, %p, %p!}\r\n",
            (uintptr_t)pc_cmd, (uintptr_t)pc_arg, (uintptr_t)pul_cmd_offset);
        return HI_ERR_CODE_PTR_NULL;
    }

    pc_cmd_copy = pc_cmd;

    /* ȥ���ַ�����ʼ�Ŀո� */
    while (*pc_cmd_copy == ' ') {
        ++pc_cmd_copy;
    }

    while ((*pc_cmd_copy != ' ') && (*pc_cmd_copy != '\0')) {
        pc_arg[pos] = *pc_cmd_copy;
        ++pos;
        ++pc_cmd_copy;

        if (oal_unlikely(pos >= pc_arg_len)) {
            oam_warning_log1(0, 0,
                "{wal_get_cmd_one_arg::ul_pos >= WAL_HIPRIV_CMD_NAME_MAX_LEN, ul_pos %d!}\r\n", pos);
            return HI_ERR_CODE_ARRAY_OVERFLOW;
        }
    }

    pc_arg[pos]  = '\0';

    /* �ַ�������β�����ش����� */
    if (pos == 0) {
        oam_info_log0(0, 0, "{wal_get_cmd_one_arg::return param pc_arg is null!}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }

    *pul_cmd_offset = (hi_u32)(pc_cmd_copy - pc_cmd);

    return HI_SUCCESS;
}

#ifdef _PRE_WLAN_FEATURE_P2P
/*****************************************************************************
 �� �� ��  : wal_wireless_iftype_to_mac_p2p_mode
 �������  : enum nl80211_iftype en_iftype
 �������  : ��
 �� �� ֵ  : wlan_p2p_mode_enum_uint8

 �޸���ʷ      :
  1.��    ��   : 2014��12��31��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
wlan_p2p_mode_enum_uint8 wal_wireless_iftype_to_mac_p2p_mode(nl80211_iftype_uint8 iftype)
{
    wlan_p2p_mode_enum_uint8 p2p_mode = WLAN_LEGACY_VAP_MODE;

    switch (iftype) {
        case NL80211_IFTYPE_P2P_CLIENT:
            p2p_mode = WLAN_P2P_CL_MODE;
            break;
        case NL80211_IFTYPE_P2P_GO:
            p2p_mode = WLAN_P2P_GO_MODE;
            break;
        case NL80211_IFTYPE_P2P_DEVICE:
            p2p_mode = WLAN_P2P_DEV_MODE;
            break;
#ifdef _PRE_WLAN_FEATURE_MESH
        case NL80211_IFTYPE_MESH_POINT:
#endif
        case NL80211_IFTYPE_AP:
        case NL80211_IFTYPE_STATION:
            p2p_mode = WLAN_LEGACY_VAP_MODE;
            break;
        default:
            p2p_mode = WLAN_P2P_BUTT;
    }
    return p2p_mode;
}
#endif

/*****************************************************************************
 ��������  : cfg vap h2d
 �������  : pst_net_dev: net_device
 �޸���ʷ      :
  1.��    ��   : 2015��6��10��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���
*****************************************************************************/
hi_u32 wal_cfg_vap_h2d_event(oal_net_device_stru *netdev)
{
    hi_unref_param(netdev);
    oal_net_device_stru         *netdev_cfg = HI_NULL;
    hi_u32                       ret;
    wal_msg_stru                *rsp_msg = HI_NULL;
    wal_msg_write_stru           write_msg;

    netdev_cfg = oal_get_netdev_by_name(WLAN_CFG_VAP_NAME);
    if (netdev_cfg == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_init_wlan_vap::pst_cfg_net_dev is null!}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }
#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
    oal_dev_put(netdev_cfg);
#endif
    /***************************************************************************
    ���¼���wal�㴦��
    ***************************************************************************/
    /* ��д��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_CFG_VAP_H2D, sizeof(mac_cfg_vap_h2d_stru));
    ((mac_cfg_vap_h2d_stru *)write_msg.auc_value)->net_dev = netdev_cfg;

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev_cfg,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_vap_h2d_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_cfg_vap_h2d_event::wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ����������Ϣ */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_cfg_vap_h2d_event::hmac cfg vap h2d fail,err code[%u]\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}
#if (_PRE_MULTI_CORE_MODE_OFFLOAD_DMAC == _PRE_MULTI_CORE_MODE)
/*****************************************************************************
 �� �� ��  : wal_host_dev_config
 ��������  : 02 host device_sruc���ýӿڣ�Ŀǰ�������µ�����
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��11��24��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���
*****************************************************************************/
static hi_u32 wal_host_dev_config(const oal_net_device_stru *netdev, wlan_cfgid_enum_uint16 wid)
{
    oal_wireless_dev           *wdev = HI_NULL;
    mac_wiphy_priv_stru        *wiphy_priv = HI_NULL;
    hmac_vap_stru              *hmac_vap = HI_NULL;
    mac_device_stru            *mac_dev = HI_NULL;
    oal_net_device_stru        *netdev_cfg = HI_NULL;
    hi_u32                      ret;
    wal_msg_stru               *rsp_msg = HI_NULL;
    wal_msg_write_stru          write_msg;

    wdev = oal_netdevice_wdev(netdev);
    if ((wdev == HI_NULL) || (wdev->wiphy == HI_NULL)) {
        oam_warning_log0(0, 0, "{wal_init_wlan_vap::pst_wdev is null!}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }

    wiphy_priv  = (mac_wiphy_priv_stru *)oal_wiphy_priv(wdev->wiphy);
    mac_dev  = wiphy_priv->mac_device;
    hmac_vap = hmac_vap_get_vap_stru(WLAN_CFG_VAP_ID);
    if (mac_dev == HI_NULL || hmac_vap == HI_NULL || hmac_vap->net_device == HI_NULL) {
        oam_warning_log2(0, 0, "{wal_init_wlan_vap::mac_dev/hmac_vap is null! mac_dev=%p,hmac_vap=%p}",
            (uintptr_t)mac_dev, (uintptr_t)hmac_vap);
        return HI_ERR_CODE_PTR_NULL;
    }
    netdev_cfg = hmac_vap->net_device;

    /***************************************************************************
    ���¼���wal�㴦��
    ***************************************************************************/
    /* ��д��Ϣ */
    wal_write_msg_hdr_init(&write_msg, wid, 0);

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev_cfg,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH,
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_cfg_vap_h2d_event::wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ����������Ϣ */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_cfg_vap_h2d_event::hmac cfg vap h2d fail,err code[%u]\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_host_dev_init
 ��������  : 02 host device_sruc�ĳ�ʼ���ӿڣ�Ŀǰ�������µ�����
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��11��24��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_host_dev_init(const oal_net_device_stru *netdev)
{
    return wal_host_dev_config(netdev, WLAN_CFGID_HOST_DEV_INIT);
}

/*****************************************************************************
 �� �� ��  : wal_host_dev_init
 ��������  : 02 host device_sruc��ȥ��ʼ���ӿڣ�Ŀǰ�������µ�����
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��11��26��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_host_dev_exit(const oal_net_device_stru *netdev)
{
    return wal_host_dev_config(netdev, WLAN_CFGID_HOST_DEV_EXIT);
}
#endif

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static hi_u32 wal_ioctl_get_mode(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
#endif

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_mode
 ��������  : ����ģʽ: ����Э�顢Ƶ�Ρ�����
 �������  : pst_net_dev: net device
             pc_param    : ����
 �������  : ��
 �� �� ֵ  : ������

 �޸���ʷ      :
  1.��    ��   : 2014��12��12��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_ioctl_set_mode(oal_net_device_stru *netdev, hi_char *pc_param)
{
    hi_char            ac_mode_str[WAL_HIPRIV_CMD_NAME_MAX_LEN] = {0};     /* Ԥ��Э��ģʽ�ַ����ռ� */
    hi_u8              prot_idx;
    wal_msg_write_stru write_msg;
    hi_u32             off_set = 0;

    if (oal_unlikely((netdev == HI_NULL) || (pc_param == HI_NULL))) {
        oam_error_log2(0, 0, "{wal_ioctl_set_mode::pst_net_dev/p_param null ptr error %p %p!}\r\n",
                       (uintptr_t)netdev, (uintptr_t)pc_param);
        return HI_ERR_WIFI_WAL_FAILURE;
    }

    /* �豸��up״̬���������ã�������down */
    if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
        oam_error_log1(0, 0, "{wal_ioctl_set_mode::device busy %d!}\r\n", oal_netdevice_flags(netdev));
        return HI_ERR_WIFI_WAL_BUSY;
    }

    /* pc_paramָ����ģʽ����, ����ȡ����ŵ�ac_mode_str�� */
    hi_u32 ret = wal_get_cmd_one_arg(pc_param, ac_mode_str, WAL_HIPRIV_CMD_NAME_MAX_LEN, &off_set);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_mode::mode get failed [%d]!}\r\n", ret);
        return ret;
    }
    ac_mode_str[sizeof(ac_mode_str) - 1] = '\0';    /* ȷ����null��β */

    for (prot_idx = 0; HI_NULL != g_ast_mode_map[prot_idx].pc_name; prot_idx++) {
        if (strcmp(g_ast_mode_map[prot_idx].pc_name, ac_mode_str) == 0) {
            break;
        }
    }

    if (HI_NULL == g_ast_mode_map[prot_idx].pc_name) {
        oam_warning_log0(0, 0, "{wal_ioctl_set_mode::unrecognized protocol string!}\r\n");
        return HI_FAIL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_MODE, sizeof(mac_cfg_mode_param_stru));

    mac_cfg_mode_param_stru *mode_param = (mac_cfg_mode_param_stru *)(write_msg.auc_value);
    mode_param->protocol     = g_ast_mode_map[prot_idx].mode;
    mode_param->band         = g_ast_mode_map[prot_idx].band;
    mode_param->en_bandwidth = g_ast_mode_map[prot_idx].en_bandwidth;

    oam_info_log3(0, OAM_SF_CFG, "{wal_ioctl_set_mode::protocol[%d],band[%d],bandwidth[%d]!}\r\n",
                  mode_param->protocol, mode_param->band, mode_param->en_bandwidth);

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_mode_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_mode::wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static hi_u32  wal_ioctl_get_essid(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
#endif

/*****************************************************************************
 �� �� ��  : oal_strim
 ��������  : ȥ���ַ�����ʼ���β�Ŀո�
 �������  : ��
 �������  : ��
 �� �� ֵ  : ����ַ���

 �޸���ʷ      :
  1.��    ��   : 2013��8��12��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_char* oal_strim(hi_char* str, hi_u8 max_cmd_len)
{
    hi_u32   size;
    hi_char* str_end = HI_NULL;

    hi_unref_param(max_cmd_len);
    while (*str == ' ') {
        ++str;
    }

    size = strlen((const hi_char *)str);
    if (!size) {
        return str;
    }

    str_end = str + size - 1;
    while ((str_end >= str) && (*str_end == ' ')) {
        str_end--;
    }

    *(str_end + 1) = '\0';

    return str;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_essid
 ��������  : ����ssid
 �������  : [1]net_dev
             [2]pc_param
 �������  : ��
 �� �� ֵ  : static hi_u32
*****************************************************************************/
/* �ṹ������g_ast_hipriv_cmd�ĳ�Ա������wal_hipriv_getcountry�޸��˶�Ӧ������lint_t e818�澯���� */
hi_u32  wal_ioctl_set_essid(oal_net_device_stru *netdev, hi_char *pc_param)
{
    wal_msg_write_stru  write_msg;
    hi_u32              off_set;
    hi_char             ac_ssid[WAL_HIPRIV_CMD_NAME_MAX_LEN] = {0};
    mac_vap_stru       *mac_vap = oal_net_dev_priv(netdev);

    if (mac_vap == NULL) {
        oam_warning_log0(0, 0, "{wal_ioctl_set_essid::pst_mac_vap is null!}");
        return HI_ERR_CODE_PTR_NULL;
    }

    if (mac_vap->vap_mode == WLAN_VAP_MODE_BSS_AP
#ifdef _PRE_WLAN_FEATURE_MESH
    || (mac_vap->vap_mode == WLAN_VAP_MODE_MESH)
#endif
    ) {
        /* �豸��up״̬����APʱ�����������ã�������down */
        if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
            oam_error_log1(mac_vap->vap_id, 0,
                "{wal_ioctl_set_essid::device is busy, please down it firste %d!}", oal_netdevice_flags(netdev));
            return HI_FAIL;
        }
    }

    /* pc_paramָ����ģʽ����, ����ȡ����ŵ�ac_mode_str�� */
    hi_u32 ret = wal_get_cmd_one_arg(pc_param, ac_ssid, WAL_HIPRIV_CMD_NAME_MAX_LEN, &off_set);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_essid::wal_get_cmd_one_arg vap name return err_code %d!}", ret);
        return ret;
    }

    hi_char *pc_ssid  = oal_strim(ac_ssid, WAL_HIPRIV_CMD_NAME_MAX_LEN); /* ȥ���ַ�����ʼ��β�Ŀո� */
    hi_u8    ssid_len = (hi_u8)strlen(pc_ssid);
    oam_info_log1(mac_vap->vap_id, 0, "{wal_ioctl_set_essid:: ssid length %d!}", ssid_len);
    ssid_len = (ssid_len > WLAN_SSID_MAX_LEN - 1) ? (WLAN_SSID_MAX_LEN - 1) : ssid_len; /* -1Ϊ\0Ԥ���ռ� */
    oam_info_log1(mac_vap->vap_id, 0, "{wal_ioctl_set_essid:: ssid length is %d!}", ssid_len);

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_SSID, sizeof(mac_cfg_ssid_param_stru));

    /* ��дWID��Ӧ�Ĳ��� */
    mac_cfg_ssid_param_stru *param = (mac_cfg_ssid_param_stru *)(write_msg.auc_value);
    param->ssid_len = ssid_len;
    if (memcpy_s(param->ac_ssid, WLAN_SSID_MAX_LEN, pc_ssid, ssid_len) != EOK) {
        oam_error_log0(0, 0, "{wal_ioctl_set_essid::mem safe function err!}");
        return HI_FAIL;
    }

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev, WAL_MSG_TYPE_WRITE, WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_ssid_param_stru),
                             (hi_u8 *)&write_msg, HI_FALSE, HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(mac_vap->vap_id, 0, "{wal_ioctl_set_essid:: wal_alloc_cfg_event Err=%u}", ret);
        return ret;
    }

    return HI_SUCCESS;
}

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static hi_u32  wal_ioctl_get_bss_type(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
static hi_u32  wal_ioctl_set_bss_type(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
static hi_u32  wal_ioctl_get_freq(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
#endif

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_freq
 ��������  : ����Ƶ��/�ŵ�
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��12��12��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
/* �ṹ������g_ast_hipriv_cmd�ĳ�Ա������wal_hipriv_getcountry�޸��˶�Ӧ������lint_t e818�澯���� */
hi_u32  wal_ioctl_set_freq(oal_net_device_stru *netdev, hi_char *pc_param)
{
    wal_msg_write_stru      write_msg;
    hi_s32                  channel;
    hi_u32                  off_set;
    hi_char                 ac_freq[WAL_HIPRIV_CMD_NAME_MAX_LEN] = {0};
    hi_u32                  ret;

    /* �豸��up״̬���������ã�������down */
    if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
        oam_error_log1(0, 0,
            "{wal_ioctl_set_freq::device is busy, please down it first %d!}\r\n", oal_netdevice_flags(netdev));
        return HI_ERR_WIFI_WAL_BUSY;
    }

    /* pc_paramָ���´�����net_device ��name, ����ȡ����ŵ�ac_name�� */
    ret = wal_get_cmd_one_arg(pc_param, ac_freq, WAL_HIPRIV_CMD_NAME_MAX_LEN, &off_set);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_freq::wal_get_cmd_one_arg vap name return err_code %u!}\r\n", ret);
        return ret;
    }

    channel = oal_atoi(ac_freq);
    if ((channel < 1) || (channel > 14)) { /* �ŵ������Ϊ14 */
        oam_warning_log1(0, 0, "{wal_ioctl_set_freq::channel set fail = %d!}\r\n", channel);
        return HI_FAIL;
    }
    oam_info_log1(0, 0, "{wal_ioctl_set_freq::channel = %d!}\r\n", channel);
    ret = mac_is_channel_num_valid(WLAN_BAND_2G, channel);
    if (ret != HI_SUCCESS) {
        oam_error_log2(0, OAM_SF_CFG, "{wal_ioctl_set_freq::channel=%d,Err=%d}", channel, ret);
        return HI_FAIL;
    }
    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    /* ��д��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_CURRENT_CHANEL, sizeof(hi_s32));
    *((hi_s32 *)(write_msg.auc_value)) = channel;

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(hi_s32),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_freq::return err code %d!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
static hi_u32  wal_ioctl_get_txpower(oal_net_device_stru *netdev, hi_s8 *pc_param)
{
    return HI_FAIL;
}
#endif

/* �ṹ������g_ast_hipriv_cmd�ĳ�Ա������wal_hipriv_getcountry�޸��˶�Ӧ������lint_t e818�澯���� */
hi_u32  wal_ioctl_set_txpower(oal_net_device_stru *netdev, hi_char *pc_param)
{
    wal_msg_write_stru       write_msg;
    hi_s32                   l_pwer;
    hi_u32                   off_set;
    hi_char                  ac_val[WAL_HIPRIV_CMD_NAME_MAX_LEN] = {0};
    hi_u32                   ret;

    ret = wal_get_cmd_one_arg(pc_param, ac_val, WAL_HIPRIV_CMD_NAME_MAX_LEN, &off_set);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_txpower::wal_get_cmd_one_arg vap name return err_code %d!}\r\n",
            ret);
        return ret;
    }

    l_pwer = oal_atoi(ac_val);

    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_TX_POWER, sizeof(hi_s32));
    *((hi_s32 *)(write_msg.auc_value)) = l_pwer;

    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(hi_s32),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_txpower::return err code %u!}", ret);
        return ret;
    }

    return HI_SUCCESS;
}

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
/*****************************************************************************
 ��������  : ��ȡ�ַ�����һ���������Զ���Ϊ�������ֱ�ʶ�����۳�����ǰ���ַ�
 �������  : pc_cmd         : ������ַ���
             puc_token      : ����ǰ���ִ�
 �������  : pc_arg         : �۵�����ǰ���ִ���Ĳ���
             pul_cmd_offset : ��һ�������ĳ���
*****************************************************************************/
static hi_u32 wal_get_parameter_from_cmd(hi_char *pc_cmd, hi_char *pc_arg, const hi_char *puc_token,
                                         hi_char *pul_cmd_offset, hi_u32 ul_param_max_len)
{
    hi_char   *pc_cmd_copy = HI_NULL;
    hi_char    ac_cmd_copy[WAL_IOCTL_PRIV_SUBCMD_MAX_LEN];
    hi_u32     pos = 0;
    hi_u32     arg_len;

    if (oal_unlikely((pc_cmd == HI_NULL) || (pc_arg == HI_NULL) || (pul_cmd_offset == HI_NULL))) {
        oam_error_log3(0, 0,
            "{wal_get_parameter_from_cmd::pc_cmd/pc_arg/pul_cmd_offset null ptr error %d, %d, %d, %d!}\r\n",
            pc_cmd, pc_arg, pul_cmd_offset);
        return HI_FAIL;
    }

    pc_cmd_copy = pc_cmd;

    /* ȥ���ַ�����ʼ�Ķ��� */
    while (*pc_cmd_copy == ',') {
        ++pc_cmd_copy;
    }
    /* ȡ�ö���ǰ���ַ��� */
    while ((*pc_cmd_copy != ',') && (*pc_cmd_copy != '\0')) {
        ac_cmd_copy[pos] = *pc_cmd_copy;
        ++pos;
        ++pc_cmd_copy;

        if (oal_unlikely(pos >= ul_param_max_len)) {
            oam_warning_log1(0, 0,
                "{wal_get_parameter_from_cmd::ul_pos >= WAL_HIPRIV_CMD_NAME_MAX_LEN, ul_pos %d!}\r\n", pos);
            return HI_FAIL;
        }
    }
    ac_cmd_copy[pos]  = '\0';
    /* �ַ�������β�����ش����� */
    if (pos == 0) {
        oam_info_log0(0, 0, "{wal_get_parameter_from_cmd::return param pc_arg is null!}\r\n");
        return HI_FAIL;
    }
    *pul_cmd_offset = (hi_u32)(pc_cmd_copy - pc_cmd);

    /* ����ַ����Ƿ����������ǰ�������ַ� */
    if (memcmp(ac_cmd_copy, puc_token, strlen(puc_token)) != 0) {
        return HI_FAIL;
    } else {
        /* �۳�ǰ�������ַ����ش����� */
        arg_len = strlen(ac_cmd_copy) - strlen(puc_token);
        memcpy_s(pc_arg, arg_len, ac_cmd_copy + strlen(puc_token), arg_len);
        pc_arg[arg_len]  = '\0';
    }
    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_apaddr
 ��������  : ��ȡBSSID
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_apaddr(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    oal_sockaddr_stru *addr, hi_s8 *pc_extra)
{
    mac_vap_stru   *mac_vap = HI_NULL;
    hi_u8          mac_addr[WLAN_MAC_ADDR_LEN] = {0};

    mac_vap = oal_net_dev_priv(netdev);
    if (mac_vap == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_ioctl_get_apaddr::pst_mac_vap is null!}\r\n");
        return HI_FAIL;
    }

    if (mac_vap->vap_state == MAC_VAP_STATE_UP) {
        if (memcpy_s(addr->sa_data, WLAN_MAC_ADDR_LEN,  mac_vap->auc_bssid, WLAN_MAC_ADDR_LEN) != EOK) {
            oam_error_log0(0, 0, "{wal_ioctl_get_apaddr::mem safe function err!}");
            return HI_FAIL;
        }
    } else {
        if (memcpy_s(addr->sa_data, WLAN_MAC_ADDR_LEN,  mac_addr, WLAN_MAC_ADDR_LEN) != EOK) {
            oam_error_log0(0, 0, "{wal_ioctl_get_apaddr::mem safe function err!}");
            return HI_FAIL;
        }
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_iwrate
 ��������  : iwconfig��ȡrate����֧�֣�����-1
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_iwrate(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    oal_iw_param_stru *param, hi_s8 *pc_extra)
{
    /* iwconfig��ȡrate����֧�ִ�����򷵻�-1 */
    return HI_FAIL;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_iwrate
 ��������  : iwconfig��ȡsense����֧�֣�����-1
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_iwsense(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    oal_iw_param_stru *param, hi_s8 *pc_extra)
{
    /* iwconfig��ȡsense����֧�ִ�����򷵻�-1 */
    return HI_FAIL;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_rtsthres
 ��������  : iwconfig��ȡrtsthres
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_rtsthres(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    oal_iw_param_stru *param, hi_s8 *pc_extra)
{
    mac_vap_stru   *mac_vap = HI_NULL;

    mac_vap = oal_net_dev_priv(netdev);
    if (mac_vap == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_ioctl_get_rtsthres::pst_mac_vap is null!}\r\n");
        return HI_FAIL;
    }

    param->value    = (hi_s32)mac_vap->mib_info->wlan_mib_operation.dot11_rts_threshold;
    param->disabled = (WLAN_RTS_MAX == param->value);
    param->fixed    = 1;

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_fragthres
 ��������  : iwconfig��ȡfragthres
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_fragthres(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                       oal_iw_param_stru *param, hi_s8 *pc_extra)
{
    mac_vap_stru   *mac_vap = HI_NULL;

    mac_vap = oal_net_dev_priv(netdev);
    if (mac_vap == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_ioctl_get_fragthres::pst_mac_vap is null!}\r\n");
        return HI_FAIL;
    }

    param->value    = (hi_s32)mac_vap->mib_info->wlan_mib_operation.dot11_fragmentation_threshold;
    param->disabled = (WLAN_FRAG_THRESHOLD_MAX == param->value);
    param->fixed    = 1;

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_iwencode
 ��������  : iwconfig��ȡencode, ��֧��
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��22��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_iwencode(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    oal_iw_point_stru *param, hi_s8 *pc_extra)
{
    /* ��֧��iwconfig��ȡencode��ֱ�ӷ���-1 */
    return HI_FAIL;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_iwrange
 ��������  : iwconfig��ȡiwrange, ��֧��
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2014��4��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_iwrange(
                oal_net_device_stru         *netdev,
                oal_iw_request_info_stru    *info,
                oal_iw_point_stru           *param,
                hi_s8                    *pc_extra)
{
    return HI_FAIL;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_param
 ��������  : iwpriv˽�л�ȡ�����������
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2013��1��17��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_param(oal_net_device_stru *netdev, oal_iw_request_info_stru *info, hi_void *iw,
    hi_s8 *pc_extra)
{
    hi_u32                       ret;
    wal_msg_stru                *rsp_msg = HI_NULL;
    wal_msg_query_stru           query_msg;
    wal_msg_rsp_stru            *query_rsp_msg = HI_NULL;
    hi_s32                      *pl_param = HI_NULL;

    pl_param = (hi_s32 *)pc_extra;
    oam_info_log1(0, 0, "{wal_ioctl_get_param::return err code %d!}\r\n", pl_param[0]);

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    query_msg.wid = (hi_u16)pl_param[0];

    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_QUERY,
                             WAL_MSG_WID_LENGTH,
                             (hi_u8 *)&query_msg,
                             HI_TRUE,
                             &rsp_msg);
    if ((ret != HI_SUCCESS) || (rsp_msg == HI_NULL)) {
        oam_warning_log1(0, 0, "{wal_ioctl_get_param::return err code %u!}\r\n", ret);
        return ret;
    }

    /* ����������Ϣ */
    query_rsp_msg = (wal_msg_rsp_stru *)(rsp_msg->auc_msg_data);

    /* ҵ���� */
    pl_param[0] = *((hi_s32 *)(query_rsp_msg->auc_value));

    oal_free(rsp_msg);
    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_param
 ��������  : iwpriv˽�����ò����������
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2013��1��17��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_set_param(oal_net_device_stru *netdev, oal_iw_request_info_stru *info, hi_void *iw,
    hi_s8 *pc_extra)
{
    hi_s32 l_error = 0;
    wal_msg_write_stru           write_msg;
    hi_u32 ret;

    /* �豸��up״̬���������ã�������down */
    if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
        oam_error_log1(0, 0, "{wal_ioctl_set_param::device is busy, please down it first %d!}\r\n",
            oal_netdevice_flags(netdev));
        return HI_FAIL;
    }

    hi_s32 *pl_param      = (hi_s32 *)pc_extra;
    hi_s32 l_subioctl_id  = pl_param[0];    /* ��ȡsub-ioctl��ID */
    hi_s32 l_value        = pl_param[1];    /* ��ȡҪ���õ�ֵ */
    oam_info_log2(0, 0,  "{wal_ioctl_set_param::subioctl_id, value is %d, %d!}\r\n", l_subioctl_id, l_value);

    if (l_value < 0) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_param::input value is negative %d!}\r\n", l_value);
        return HI_FAIL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, (hi_u16)l_subioctl_id, sizeof(hi_s32));
    if (l_subioctl_id == WLAN_CFGID_PROT_MODE) {
        if (l_value >= WLAN_PROT_BUTT) { /* ������� */
            l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
        }
    } else if (l_subioctl_id == WLAN_CFGID_AUTH_MODE) {
        if (l_value >= WLAN_WITP_ALG_AUTH_BUTT) {  /* ������� */
            l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
        }
    } else if (l_subioctl_id == WLAN_CFGID_BEACON_INTERVAL) {
        if (l_value > WLAN_BEACON_INTVAL_MAX || l_value < WLAN_BEACON_INTVAL_MIN) {
            l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
        }
    } else if (l_subioctl_id == WLAN_CFGID_DTIM_PERIOD) {
        if (l_value > WLAN_DTIM_PERIOD_MAX || l_value < WLAN_DTIM_PERIOD_MIN) {
            oam_error_log1(0, 0, "{wal_ioctl_set_param::input dtim_period invalid %d!}\r\n", l_value);
            l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
        }
    }

    if (l_error != 0) {          /* �����쳣 */
        return l_error;
    }

    *((hi_s32 *)(write_msg.auc_value)) = l_value;   /* ��дset��Ϣ��payload */

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev, WAL_MSG_TYPE_WRITE, WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(hi_s32),
        (hi_u8 *)&write_msg, HI_FALSE, HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_param::return err code %u!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/* ��̹淶����5.1 ���⺯������������������50�У��ǿշ�ע�ͣ�����������: ������Ч���жϣ��߼��򵥣����ܾۺ��Բ���� */
static hi_u32 wal_ioctl_check_wme_params(hi_s32 l_subioctl_id, hi_s32 l_value)
{
    hi_s32 l_error = 0;
    switch (l_subioctl_id) {                                                    /* ����sub-ioctl id��дWID */
        case WLAN_CFGID_EDCA_TABLE_CWMIN:
            if ((l_value > WLAN_QEDCA_TABLE_CWMIN_MAX) || (l_value < WLAN_QEDCA_TABLE_CWMIN_MIN)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_EDCA_TABLE_CWMAX:
            if ((l_value > WLAN_QEDCA_TABLE_CWMAX_MAX) || (l_value < WLAN_QEDCA_TABLE_CWMAX_MIN)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_EDCA_TABLE_AIFSN:
            if ((l_value < WLAN_QEDCA_TABLE_AIFSN_MIN) || (l_value > WLAN_QEDCA_TABLE_AIFSN_MAX)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_EDCA_TABLE_TXOP_LIMIT:
            if ((l_value > WLAN_QEDCA_TABLE_TXOP_LIMIT_MAX) || (l_value < WLAN_QEDCA_TABLE_TXOP_LIMIT_MIN)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_EDCA_TABLE_MSDU_LIFETIME:
            if (l_value > WLAN_QEDCA_TABLE_MSDU_LIFETIME_MAX) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_EDCA_TABLE_MANDATORY:
            if ((l_value != HI_TRUE) &&  (l_value != HI_FALSE)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_CWMIN:
            if ((l_value > WLAN_QEDCA_TABLE_CWMIN_MAX) || (l_value < WLAN_QEDCA_TABLE_CWMIN_MIN)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_CWMAX:
            if ((l_value > WLAN_QEDCA_TABLE_CWMAX_MAX) || (l_value < WLAN_QEDCA_TABLE_CWMAX_MIN)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_AIFSN:
            if ((l_value < WLAN_QEDCA_TABLE_AIFSN_MIN) || (l_value > WLAN_QEDCA_TABLE_AIFSN_MAX)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_TXOP_LIMIT:
            if (l_value > WLAN_QEDCA_TABLE_TXOP_LIMIT_MAX) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_MSDU_LIFETIME:
            if (l_value > WLAN_QEDCA_TABLE_MSDU_LIFETIME_MAX) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }
            break;

        case WLAN_CFGID_QEDCA_TABLE_MANDATORY:
            if ((l_value != HI_TRUE) &&  (l_value != HI_FALSE)) {
                l_error = HI_ERR_WIFI_WAL_INVALID_PARAMETER;
            }

            break;

        default:
            break;
    }

    if (l_error != 0) {          /* �����쳣 */
        return HI_FAIL;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_wme_params
 ��������  : iwpriv˽�����ò����������
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_s32

 �޸���ʷ      :
  1.��    ��   : 2013��5��9��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_s32  wal_ioctl_set_wme_params(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    hi_void *iw, hi_s8 *pc_extra)
{
    hi_u32                       ret;
    hi_s32                      *pl_param = HI_NULL;
    hi_s32                       l_subioctl_id;
    hi_s32                       l_ac;
    hi_s32                       l_value;
    wal_msg_write_stru           write_msg;
    wal_msg_wmm_stru            *wmm_params = HI_NULL;

    /* �豸��up״̬���������ã�������down */
    if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
        oam_error_log1(0, 0, "{wal_ioctl_set_wme_params::device is busy, please down it first %d!}\r\n",
            oal_netdevice_flags(netdev));
        return HI_FAIL;
    }

    pl_param      = (hi_s32 *)pc_extra;
    l_subioctl_id = pl_param[0];    /* ��ȡsub-ioctl��ID */
    l_ac          = pl_param[1];
    l_value       = pl_param[2];    /* 2: ��ȡҪ���õ�ֵ */

    oam_info_log3(0, 0, "{wal_ioctl_set_wme_params::the subioctl_id,l_ac,value is %d, %d, %d!}\r\n",
        l_subioctl_id, l_ac, l_value);

    /* acȡֵ0~3, value����Ϊ��ֵ */
    if ((l_value < 0) || (l_ac < 0) || (l_ac >= WLAN_WME_AC_BUTT)) {
        oam_warning_log2(0, 0, "{wal_ioctl_set_wme_params::input value is negative %d, %d!}\r\n",
            l_value, l_ac);
        return HI_FAIL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    if (wal_ioctl_check_wme_params(l_subioctl_id, l_value) != HI_SUCCESS) {          /* �����쳣 */
        return HI_FAIL;
    }

    wal_write_msg_hdr_init(&write_msg, (hi_u16)l_subioctl_id, sizeof(wal_msg_wmm_stru));

    wmm_params               = (wal_msg_wmm_stru *)(write_msg.auc_value);
    wmm_params->cfg_id    = (hi_u16)l_subioctl_id;
    wmm_params->ac        = (hi_u32)l_ac;                     /* ��дset��Ϣ��payload */
    wmm_params->value     = (hi_u32)l_value;                  /* ��дset��Ϣ��payload */

    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(wal_msg_wmm_stru),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_wme_params::return err code %u!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_get_wme_params
 ��������  : iwpriv˽�л�ȡ�����������
 �������  : ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2013��5��9��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_wme_params(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    hi_void *iw, hi_s8 *pc_extra)
{
    hi_s32                     *param = HI_NULL;
    mac_vap_stru               *mac_vap = HI_NULL;
    wal_msg_query_stru          query_msg;
    wal_msg_stru               *rsp_msg = HI_NULL;
    wal_msg_rsp_stru           *query_rsp_msg = HI_NULL;
    hmac_config_wmm_para_stru  *wmm_para = HI_NULL;
    hi_u32                      ret;
    hi_s32                     *pl_param = HI_NULL;

    param = (hi_s32 *)pc_extra;
    mac_vap = oal_net_dev_priv(netdev);
    if (oal_unlikely(mac_vap == HI_NULL)) {
        oam_error_log0(0, 0, "{wal_ioctl_get_wme_params::oal_net_dev_priv(pst_net_dev) is null ptr.}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }
    pl_param = (hi_s32 *)pc_extra;
    oam_info_log1(0, OAM_SF_WMM, "{wal_ioctl_get_wme_params::return err code %d!}\r\n", pl_param[0]);
    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    query_msg.wid = (hi_u16)pl_param[0];

     /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_QUERY,
                             WAL_MSG_WID_LENGTH,
                             (hi_u8 *)&query_msg,
                             HI_TRUE,
                             &rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_get_wme_params::fail to get wmm params, error[%u]}", ret);
        return ret;
    }

    /* ����������Ϣ */
    query_rsp_msg = (wal_msg_rsp_stru *)(rsp_msg->auc_msg_data);

    /* ҵ���� */
    wmm_para = (hmac_config_wmm_para_stru*)(query_rsp_msg->auc_value);
    param[0] = wmm_para->value;

    oal_free(rsp_msg);

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_setcountry
 ��������  : ���ù����������
 �������  : pst_net_dev: net device
             pst_info   : �������Ϣ
             p_w        : �������Ϣ
             pc_extra   : �����ַ���
 �������  : ��
 �� �� ֵ  : ������

 �޸���ʷ      :
  1.��    ��   : 2013��10��16��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_setcountry(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
    hi_void *w, hi_s8 *pc_extra)
{
    hi_u32  ret;

    /* �豸��up״̬���������ã�������down */
    if ((OAL_IFF_RUNNING & oal_netdevice_flags(netdev)) != 0) {
        oam_info_log1(0, 0, "{wal_ioctl_setcountry::country is %d, %d!}\r\n", oal_netdevice_flags(netdev));
        return HI_FAIL;
    }

    ret = wal_regdomain_update(netdev, pc_extra, MAC_CONTRY_CODE_LEN);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_setcountry::regdomain_update return err code %u!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_getcountry
 ��������  : ��ȡ������
 �������  : pst_net_dev: net device
             pst_info   : �������Ϣ
             p_w        : �������Ϣ
 �������  : pc_extra   : ��ȡ���Ĺ�����
 �� �� ֵ  : ������

 �޸���ʷ      :
  1.��    ��   : 2013��10��16��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_getcountry(oal_net_device_stru *netdev, oal_iw_request_info_stru *info, hi_void *w,
    hi_s8 *pc_extra)
{
    hi_u32                          ret;
    wal_msg_query_stru              query_msg;
    wal_msg_stru                   *rsp_msg = HI_NULL;
    wal_msg_rsp_stru               *query_rsp_msg = HI_NULL;
    mac_cfg_get_country_stru       *get_country = HI_NULL;
    oal_iw_point_stru              *iw_point = (oal_iw_point_stru *)w;

    /***************************************************************************
       ���¼���wal�㴦��
    ***************************************************************************/
    query_msg.wid = WLAN_CFGID_COUNTRY;

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_QUERY,
                             WAL_MSG_WID_LENGTH,
                             (hi_u8 *)&query_msg,
                             HI_TRUE,
                             &rsp_msg);
    if ((ret != HI_SUCCESS)  || (rsp_msg == HI_NULL)) {
        oam_error_log1(0, 0, "{wal_ioctl_getcountry:: wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }
    /* ����������Ϣ */
    query_rsp_msg = (wal_msg_rsp_stru *)(rsp_msg->auc_msg_data);
    /* ҵ���� */
    get_country = (mac_cfg_get_country_stru*)(query_rsp_msg->auc_value);
    if (get_country->ac_country != HI_NULL) {
        if (memcpy_s(pc_extra, WLAN_COUNTRY_STR_LEN, get_country->ac_country, WLAN_COUNTRY_STR_LEN) != EOK) {
            oam_error_log0(0, 0, "{wal_ioctl_getcountry::mem safe function err!}");
            oal_free(rsp_msg);
            return HI_FAIL;
        }
    }
    iw_point->length = WLAN_COUNTRY_STR_LEN;
    oal_free(rsp_msg);

    return HI_SUCCESS;
}

/*****************************************************************************
 ��������  : netd�·�����ȡ�ù����豸�б�
 �������  : oal_iw_request_info_stru *pst_info
             oal_iwreq_data_union *pst_wrqu
*****************************************************************************/
static hi_s32 wal_ioctl_get_assoc_list(oal_net_device_stru *net_dev, oal_iw_request_info_stru *info,
    oal_iwreq_data_union *wrqu, hi_s8 *pc_extra)
{
    hi_s32                       l_ret;
    wal_msg_query_stru              st_query_msg;
    wal_msg_stru                   *pst_rsp_msg = HI_NULL;
    wal_msg_rsp_stru               *pst_query_rsp_msg = HI_NULL;
    hi_char                       *pc_sta_list = HI_NULL;
    oal_netbuf_stru                *pst_response_netbuf = HI_NULL;

    if (oal_unlikely(info == HI_NULL || wrqu == HI_NULL || pc_extra == HI_NULL)) {
        oam_warning_log3(0, 0,
            "{wal_ioctl_get_assoc_list:: param is HI_NULL , pst_info = %p , pst_wrqu = %p , pc_extra = %p}\n",
            info, wrqu, pc_extra);
        return -OAL_EFAIL;
    }

    /* �ϲ����κ�ʱ�򶼿����·��������Ҫ���жϵ�ǰnetdev��״̬����ʱ���� */
    if (oal_unlikely(oal_net_dev_priv(net_dev) == HI_NULL)) {
        return -OAL_EFAIL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    st_query_msg.wid = WLAN_CFGID_GET_STA_LIST;

    /* ������Ϣ */
    l_ret = wal_send_cfg_event(net_dev,
                               WAL_MSG_TYPE_QUERY,
                               WAL_MSG_WID_LENGTH,
                               (hi_u8 *)&st_query_msg,
                               HI_TRUE,
                               &pst_rsp_msg);
    if ((l_ret != HI_SUCCESS)  || (pst_rsp_msg == HI_NULL)) {
        oam_error_log1(0, 0, "{wal_ioctl_get_assoc_list:: wal_alloc_cfg_event return err code %d!}\r\n",
            l_ret);
        return l_ret;
    }

    /* ����������Ϣ */
    pst_query_rsp_msg = (wal_msg_rsp_stru *)(pst_rsp_msg->auc_msg_data);
    /* ҵ���� */
    if (pst_query_rsp_msg->us_len >= sizeof(oal_netbuf_stru)) {
        /* ��ȡhmac�����netbufָ�� */
        memcpy_s(&pst_response_netbuf, sizeof(oal_netbuf_stru),
                 pst_query_rsp_msg->auc_value, sizeof(oal_netbuf_stru));
        if (pst_response_netbuf != HI_NULL) {
            /* ����ap�����sta��ַ��Ϣ */
            pc_sta_list = (hi_char*)oal_netbuf_data(pst_response_netbuf);
            wrqu->data.length = (hi_u16)(oal_netbuf_len(pst_response_netbuf) + 1);
            memcpy_s(pc_extra, wrqu->data.length, pc_sta_list, wrqu->data.length);
            pc_extra[oal_netbuf_len(pst_response_netbuf)] = '\0';
            oal_netbuf_free(pst_response_netbuf);
        } else {
            l_ret = -OAL_ENOMEM;
        }
    } else {
        oal_print_hex_dump((hi_u8 *)pst_rsp_msg->auc_msg_data, pst_query_rsp_msg->us_len,
            32, "query msg: "); /* group size 32 */
        l_ret = -OAL_EINVAL;
    }

    if (l_ret != HI_SUCCESS) {
        oam_error_log1(0, 0, "{wal_ioctl_get_assoc_list::process failed,ret=%d}", l_ret);
    } else {
        oal_io_print2("wal_ioctl_get_assoc_list,pc_sta_list is:%s,len:%d\n", pc_extra, wrqu->data.length);
    }

    oal_free(pst_rsp_msg);
    return l_ret;
}

/*****************************************************************************
 ��������  : set ap mac filter mode to hmac
*****************************************************************************/
static hi_s32 wal_config_mac_filter(oal_net_device_stru *net_dev, hi_char *pc_command)
{
    hi_char                    parsed_command[WAL_IOCTL_PRIV_SUBCMD_MAX_LEN];
    hi_char                   *pc_parse_command = HI_NULL;
    hi_u32                     ul_mac_mode;
    hi_u32                     ul_mac_cnt;
    hi_u32                     ul_i;
#ifdef _PRE_WLAN_FEATURE_CUSTOM_SECURITY
    wal_msg_write_stru         st_write_msg;
    hi_u16                     us_len;
    wal_msg_stru              *pst_rsp_msg = HI_NULL;
    hi_u32                     ul_err_code;
    hi_s32                     l_ret = 0;
#endif
    hi_u32                     ul_ret;
    hi_char                    off_set;

    if (pc_command == HI_NULL) {
        return -OAL_EINVAL;
    }
    pc_parse_command = pc_command;

    /* ����MAC_MODE */
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, parsed_command, "MAC_MODE=", &off_set,
        WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_config_mac_filter::wal_get_parameter_from_cmd return err_code %u.}\r\n", ul_ret);
        return -OAL_EINVAL;
    }
    /* �������Ƿ�Ϸ� 0,1,2 */
    ul_mac_mode = (hi_u32)oal_atoi(parsed_command);
    if (ul_mac_mode > 2) {  /* mac mode 2 */
        oam_warning_log4(0, 0, "{wal_config_mac_filter::invalid MAC_MODE[%c%c%c%c]!}\r\n",
            (hi_u8)parsed_command[0], (hi_u8)parsed_command[1],     /* command 0/1 */
            (hi_u8)parsed_command[2], (hi_u8)parsed_command[3]);    /* command 2/3 */
        return -OAL_EINVAL;
    }

    /* ���ù���ģʽ */
#ifdef _PRE_WLAN_FEATURE_CUSTOM_SECURITY
    ul_ret = wal_hipriv_send_cfg_uint32_data(net_dev, parsed_command, WLAN_CFGID_BLACKLIST_MODE);
    if (ul_ret != HI_SUCCESS) {
        return (hi_s32)ul_ret;
    }
#endif
    /* ����MAC_CNT */
    pc_parse_command += off_set;
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, parsed_command, "MAC_CNT=", &off_set,
        WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_config_mac_filter::wal_get_parameter_from_cmd return err_code [%u]!}\r\n", ul_ret);
        return -OAL_EINVAL;
    }
    ul_mac_cnt = (hi_u32)oal_atoi(parsed_command);

    for (ul_i = 0; ul_i < ul_mac_cnt; ul_i++) {
        pc_parse_command += off_set;
        ul_ret = wal_get_parameter_from_cmd(pc_parse_command, parsed_command, "MAC=", &off_set,
            WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
        if (ul_ret != HI_SUCCESS) {
            oam_warning_log1(0, 0,
                "{wal_config_mac_filter::wal_get_parameter_from_cmd return err_code [%u]!}\r\n", ul_ret);
            return -OAL_EINVAL;
        }
        /* 5.1  �������Ƿ����MAC���� */
        if (WLAN_MAC_ADDR_LEN * 2 != strlen(parsed_command)) {  /* mac len mul 2 */
            oam_warning_log0(0, 0, "{wal_config_mac_filter::invalid MAC format}\r\n");
            return -OAL_EINVAL;
        }
        /* 6. ���ӹ����豸 */
#ifdef _PRE_WLAN_FEATURE_CUSTOM_SECURITY
        /***************************************************************************
                             ���¼���wal�㴦��
        ***************************************************************************/
        memset_s((hi_u8*)&st_write_msg, sizeof(st_write_msg), 0, sizeof(st_write_msg));
        oal_strtoaddr(parsed_command, st_write_msg.auc_value); /* ���ַ� ac_name ת�������� mac_add[6] */

        us_len = OAL_MAC_ADDR_LEN;

        if (ul_i == (ul_mac_cnt - 1)) {
            /* �����е�mac��ַ��������ɺ󣬲Ž��й����û�ȷ�ϣ��Ƿ���Ҫɾ�� */
            wal_write_msg_hdr_init(&st_write_msg, WLAN_CFGID_ADD_BLACK_LIST, us_len);
        } else {
            wal_write_msg_hdr_init(&st_write_msg, WLAN_CFGID_ADD_BLACK_LIST_ONLY, us_len);
        }

        /* 6.1  ������Ϣ */
        l_ret = wal_send_cfg_event(net_dev,
                                   WAL_MSG_TYPE_WRITE,
                                   WAL_MSG_WRITE_MSG_HDR_LENGTH + us_len,
                                   (hi_u8 *)&st_write_msg,
                                   HI_TRUE,
                                   &pst_rsp_msg);
        if ((l_ret != HI_SUCCESS)  || (pst_rsp_msg == HI_NULL)) {
            oam_error_log1(0, 0,
                "{wal_config_mac_filter:: wal_send_cfg_event return err code %d!}\r\n", l_ret);
            return l_ret;
        }

        /* 6.2  ��ȡ���صĴ����� */
        ul_err_code = wal_check_and_release_msg_resp(pst_rsp_msg);
        if (ul_err_code != HI_SUCCESS) {
            oam_error_log1(0, OAM_SF_CFG, "{wal_config_mac_filter::wal_send_cfg_event return err code:[%x]!}\r\n",
                           ul_err_code);
            return -OAL_EFAIL;
        }
#endif
    }

    /* ÿ���������mac��ַ���˺���մ��м���� */
    memset_s(g_st_ap_config_info.ac_ap_mac_filter_mode, sizeof(g_st_ap_config_info.ac_ap_mac_filter_mode),
             0, sizeof(g_st_ap_config_info.ac_ap_mac_filter_mode));

    return HI_SUCCESS;
}

/*****************************************************************************
 ��������  : deauth auc_mac_addr in ap mode
*****************************************************************************/
static hi_s32 wal_kick_sta(oal_net_device_stru *net_dev, hi_u8 *mac_addr, hi_u8 addr_len)
{
#ifdef _PRE_WLAN_FEATURE_CUSTOM_SECURITY
    wal_msg_write_stru          st_write_msg;
    wal_msg_stru               *pst_rsp_msg = HI_NULL;
    hi_u32                  ul_err_code;
    mac_cfg_kick_user_param_stru   *pst_kick_user_param;
    hi_s32                       l_ret;
#endif

    if (mac_addr == NULL) {
        oam_error_log0(0, 0, "{wal_kick_sta::argument auc_mac_addr is null.\n");
        return -OAL_EFAIL;
    }
    hi_unref_param(addr_len);

#ifdef _PRE_WLAN_FEATURE_CUSTOM_SECURITY

    WAL_WRITE_MSG_HDR_INIT(&st_write_msg, WLAN_CFGID_KICK_USER, sizeof(mac_cfg_kick_user_param_stru));

    pst_kick_user_param = (mac_cfg_kick_user_param_stru *)(st_write_msg.auc_value);
    oal_set_mac_addr(pst_kick_user_param->auc_mac_addr, mac_addr);

    pst_kick_user_param->us_reason_code = MAC_AUTH_NOT_VALID;

    l_ret = wal_send_cfg_event(net_dev,
                               WAL_MSG_TYPE_WRITE,
                               WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_kick_user_param_stru),
                               (hi_u8 *)&st_write_msg,
                               HI_TRUE,
                               &pst_rsp_msg);
    if ((l_ret != HI_SUCCESS)  || (pst_rsp_msg == HI_NULL)) {
        oam_error_log1(0, 0, "{wal_kick_sta:: wal_send_cfg_event return err code %d!}\r\n", l_ret);
        return l_ret;
    }

    /* 4.4  ��ȡ���صĴ����� */
    ul_err_code = wal_check_and_release_msg_resp(pst_rsp_msg);
    if (ul_err_code != HI_SUCCESS) {
        oam_error_log1(0, OAM_SF_CFG, "{wal_kick_sta::wal_send_cfg_event return err code: [%x]!}\r\n",
                       ul_err_code);
        return -OAL_EFAIL;
    }
#endif

    return HI_SUCCESS;
}

/*****************************************************************************
 ��������  : netd�·��������ú������������
 �������  : oal_iw_request_info_stru *pst_info
             oal_iwreq_data_union *pst_wrqu
*****************************************************************************/
static hi_s32 wal_ioctl_set_mac_filters(oal_net_device_stru *net_dev, oal_iw_request_info_stru *info,
                                        oal_iwreq_data_union *wrqu, hi_s8 *pc_extra)
{
    mac_vap_stru           *pst_vap           = HI_NULL;
    hi_char                *pc_command        = HI_NULL;
    hi_s32                  l_ret;
    hi_u32                  ul_ret;
    hi_char                 parsed_command[WAL_IOCTL_PRIV_SUBCMD_MAX_LEN];
    hi_char                *pc_parse_command = HI_NULL;
    hi_u32                  ul_mac_mode;
    hi_u32                  ul_mac_cnt;
    hi_u8                   mac_addr[WLAN_MAC_ADDR_LEN];
    hi_char                 off_set;

    if (oal_unlikely(info == HI_NULL || wrqu == HI_NULL || pc_extra == HI_NULL)) {
        oam_warning_log3(0, 0,
            "{wal_ioctl_set_mac_filters:: param is HI_NULL , pst_info = %p , pst_wrqu = %p , pc_extra = %p}\n",
            info, wrqu, pc_extra);
        return -OAL_EFAIL;
    }

    /* 1. �����ڴ汣��netd �·������������ */
    pc_command = oal_memalloc((hi_s32)(wrqu->data.length + 1));
    if (pc_command == HI_NULL) {
        return -OAL_ENOMEM;
    }

    /* 2. ����netd ����ں�̬�� */
    memset_s(pc_command, (hi_u32)(wrqu->data.length + 1), 0, (hi_u32)(wrqu->data.length + 1));
    ul_ret = oal_copy_from_user(pc_command, (hi_u32)(wrqu->data.length),
                                wrqu->data.pointer, (hi_u32)(wrqu->data.length));
    if (ul_ret != HI_SUCCESS) {
        oam_error_log0(0, 0, "{wal_ioctl_set_mac_filters::oal_copy_from_user: -OAL_EFAIL }\r\n");
        oal_free(pc_command);
        return -OAL_EFAIL;
    }
    pc_command[wrqu->data.length] = '\0';

    oal_io_print2("wal_ioctl_set_mac_filters,data len:%d, command is:%s\n", wrqu->data.length, pc_command);

    pc_parse_command = pc_command;

    memset_s(g_st_ap_config_info.ac_ap_mac_filter_mode, sizeof(g_st_ap_config_info.ac_ap_mac_filter_mode),
             0, sizeof(g_st_ap_config_info.ac_ap_mac_filter_mode));
    l_ret = strcpy_s(g_st_ap_config_info.ac_ap_mac_filter_mode, sizeof(g_st_ap_config_info.ac_ap_mac_filter_mode),
        pc_command);
    if (l_ret != EOK) {
        oam_error_log0(0, 0, "{wal_ioctl_set_mac_filters::strcpy_s fail }\r\n");
    }

    pst_vap = oal_net_dev_priv(net_dev);
    if (pst_vap == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_ioctl_set_mac_filters::netdevice vap is null,just save it.}\r\n");
        oal_free(pc_command);
        return HI_SUCCESS;
    }

    /* 3  ����MAC_MODE */
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, parsed_command, "MAC_MODE=",
                                        &off_set, WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_mac_filters::wal_get_parameter_from_cmd return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }
    /* 3.1 �������Ƿ�Ϸ� 0,1,2 */
    ul_mac_mode = (hi_u32)oal_atoi(parsed_command);
    if (ul_mac_mode > 2) {  /* mac mode 2 */
        oam_warning_log4(0, 0, "{wal_ioctl_set_mac_filters::invalid MAC_MODE[%c%c%c%c]!}",
            (hi_u8)parsed_command[0], (hi_u8)parsed_command[1],     /* command 0/1 */
            (hi_u8)parsed_command[2], (hi_u8)parsed_command[3]);    /* command 2/3 */
        oal_free(pc_command);
        return -OAL_EINVAL;
    }

    /* 5 ����MAC_CNT */
    pc_parse_command += off_set;
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, parsed_command, "MAC_CNT=", &off_set,
        WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_mac_filters::wal_get_parameter_from_cmd return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }
    ul_mac_cnt = (hi_u32)oal_atoi(parsed_command);

    l_ret = wal_config_mac_filter(net_dev, pc_command);
    if (l_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_ioctl_set_mac_filters::wal_config_mac_filter return err_code [%u]!}\r\n", l_ret);
    }

    /* ����ǰ�����ģʽ�����·�����MAC��ַΪ�գ����������κ��豸��������Ҫȥ���������Ѿ�������STA */
    if ((ul_mac_cnt == 0) && (ul_mac_mode == 2)) {  /* mac mode equal 2 */
        oam_warning_log0(0, 0, "{wal_ioctl_set_mac_filters::delete all user!}");

        memset_s(mac_addr, WLAN_MAC_ADDR_LEN, 0xff, WLAN_MAC_ADDR_LEN);
        l_ret = wal_kick_sta(net_dev, mac_addr, WLAN_MAC_ADDR_LEN);
    }

    oal_free(pc_command);
    return l_ret;
}

/*****************************************************************************
 ��������  : set ap max user count to hmac
 �������  : oal_net_device_stru *pst_net_dev
                         : hi_u32 ul_ap_max_user
*****************************************************************************/
static hi_s32 wal_set_ap_max_user(oal_net_device_stru *net_dev, hi_u32 ap_max_user)
{
    wal_msg_write_stru          st_write_msg;
    wal_msg_stru               *pst_rsp_msg = HI_NULL;
    hi_u32                  ul_err_code;
    hi_s32                   l_ret;

    oam_warning_log1(0, 0, "{wal_set_ap_max_user:: ap_max_user is : %u.}\r\n", ap_max_user);

    if (ap_max_user == 0) {
        oam_warning_log1(0, 0, "{wal_set_ap_max_user::invalid ap max user(%u),ignore this set.}\r\n", ap_max_user);
        return HI_SUCCESS;
    }

    wal_write_msg_hdr_init(&st_write_msg, WLAN_CFGID_SET_MAX_USER, sizeof(ap_max_user));
     *((hi_u32 *)st_write_msg.auc_value) = ap_max_user;
    l_ret = wal_send_cfg_event(net_dev,
                               WAL_MSG_TYPE_WRITE,
                               WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(ap_max_user),
                               (hi_u8 *)&st_write_msg,
                               HI_TRUE,
                               &pst_rsp_msg);
    if ((l_ret != HI_SUCCESS) || (pst_rsp_msg == HI_NULL)) {
        oam_error_log1(0, 0, "{wal_set_ap_max_user:: wal_send_cfg_event return err code %d!}\r\n", l_ret);

        return l_ret;
    }

    /* ��ȡ���صĴ����� */
    ul_err_code = wal_check_and_release_msg_resp(pst_rsp_msg);
    if (ul_err_code != HI_SUCCESS) {
        oam_error_log1(0, OAM_SF_CFG, "{wal_set_ap_max_user::wal_send_cfg_event return err code: [%d]!}\r\n",
                       ul_err_code);
        return -OAL_EFAIL;
    }

    /* ÿ����������û�����ɺ󣬶����Ϊ�Ƿ�ֵ0 */
    g_st_ap_config_info.ap_max_user = 0;

    return l_ret;
}

/*****************************************************************************
 ��������  : ����netd�·�APUT config���� (����û���)
 �������  : oal_iw_request_info_stru *pst_info
             oal_iwreq_data_union *pst_wrqu
*****************************************************************************/
static hi_s32 wal_ioctl_set_ap_config(oal_net_device_stru *net_dev, oal_iw_request_info_stru *info,
                                      oal_iwreq_data_union *wrqu, hi_s8 *pc_extra)
{
    hi_char                *pc_command        = HI_NULL;
    hi_char                *pc_parse_command  = HI_NULL;
    hi_s32                  l_ret             = HI_SUCCESS;
    hi_u32                  ul_ret;
    hi_char                 ac_parse_command[WAL_IOCTL_PRIV_SUBCMD_MAX_LEN];
    hi_char                 off_set;

    /* 1. �����ڴ汣��netd �·������������ */
    pc_command = oal_memalloc((hi_s32)(wrqu->data.length + 1));
    if (pc_command == HI_NULL) {
        return -OAL_ENOMEM;
    }
    /* 2. ����netd ����ں�̬�� */
    memset_s(pc_command, (hi_u32)(wrqu->data.length + 1), 0, (hi_u32)(wrqu->data.length + 1));
    ul_ret = oal_copy_from_user(pc_command, (hi_u32)(wrqu->data.length),
                                wrqu->data.pointer, (hi_u32)(wrqu->data.length));
    if (ul_ret != HI_SUCCESS) {
        oam_error_log0(0, 0, "{wal_ioctl_set_ap_config::oal_copy_from_user: -OAL_EFAIL }\r\n");
        oal_free(pc_command);
        return -OAL_EFAIL;
    }
    pc_command[wrqu->data.length] = '\0';

    oal_io_print2("wal_ioctl_set_ap_config,data len:%u,command is:%s\n", (hi_u32)wrqu->data.length, pc_command);

    pc_parse_command = pc_command;
    /* 3.   �������� */
    /* 3.1  ����ASCII_CMD */
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, ac_parse_command, "ASCII_CMD=",
                                        &off_set, WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_ap_config::wal_get_parameter_from_cmd ASCII_CMD return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }

    if (strcmp("AP_CFG", ac_parse_command) != 0) {
        oam_warning_log0(0, 0, "{wal_ioctl_set_ap_config::sub_command != 'AP_CFG' }");
        oal_io_print1("{wal_ioctl_set_ap_config::sub_command %6s...!= 'AP_CFG' }", ac_parse_command);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }

    /* 3.2  ����CHANNEL��Ŀǰ������netd�·���channel��Ϣ */
    pc_parse_command += off_set;
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, ac_parse_command, "CHANNEL=",
                                        &off_set, WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_ap_config::wal_get_parameter_from_cmd CHANNEL return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }

    /* 3.3  ����MAX_SCB */
    pc_parse_command += off_set;
    ul_ret = wal_get_parameter_from_cmd(pc_parse_command, ac_parse_command, "MAX_SCB=",
        &off_set, WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_ap_config::wal_get_parameter_from_cmd MAX_SCB return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }

    g_st_ap_config_info.ap_max_user = (hi_u32)oal_atoi(ac_parse_command);

    oam_warning_log1(0, 0,
        "{wal_ioctl_set_ap_config:: 1131_debug:: ul_ap_max_user = [%d]!}\r\n", g_st_ap_config_info.ap_max_user);

    if (oal_net_dev_priv(net_dev) != HI_NULL) {
        l_ret = wal_set_ap_max_user(net_dev, (hi_u32)oal_atoi(ac_parse_command));
    }

    /* 5. �����ͷ��ڴ� */
    oal_free(pc_command);
    return l_ret;
}

/*****************************************************************************
 ��������  : netd�·�����ȥ����STA
 �������  : oal_iw_request_info_stru *pst_info
             oal_iwreq_data_union *pst_wrqu
*****************************************************************************/
static hi_s32 wal_ioctl_set_ap_sta_disassoc(oal_net_device_stru *net_dev, oal_iw_request_info_stru *info,
                                            oal_iwreq_data_union *wrqu, hi_s8 *pc_extra)
{
    hi_char                       *pc_command        = HI_NULL;
    hi_s32                       l_ret;
    hi_u32                      ul_ret;
    hi_char                        parsed_command[WAL_IOCTL_PRIV_SUBCMD_MAX_LEN] = {0};
    hi_u8                       mac_addr[WLAN_MAC_ADDR_LEN] = {0};
    hi_char                      off_set;

    /* 1. �����ڴ汣��netd �·������������ */
    pc_command = oal_memalloc((hi_s32)(wrqu->data.length + 1));
    if (pc_command == HI_NULL) {
        return -OAL_ENOMEM;
    }

    /* 2. ����netd ����ں�̬�� */
    memset_s(pc_command, (hi_u32)(wrqu->data.length + 1), 0, (hi_u32)(wrqu->data.length + 1));
    ul_ret = oal_copy_from_user(pc_command, (hi_u32)(wrqu->data.length),
                                wrqu->data.pointer, (hi_u32)(wrqu->data.length));
    if (ul_ret != HI_SUCCESS) {
        oam_error_log0(0, 0, "{wal_ioctl_set_ap_sta_disassoc::oal_copy_from_user: -OAL_EFAIL }\r\n");
        oal_free(pc_command);
        return -OAL_EFAIL;
    }
    pc_command[wrqu->data.length] = '\0';

    oal_io_print1("wal_ioctl_set_ap_sta_disassoc,command is:%s\n", pc_command);

    /* 3. ���������ȡMAC */
    ul_ret = wal_get_parameter_from_cmd(pc_command, parsed_command, "MAC=", &off_set, WAL_IOCTL_PRIV_SUBCMD_MAX_LEN);
    if (ul_ret != HI_SUCCESS) {
        oam_warning_log1(0, 0,
            "{wal_ioctl_set_ap_sta_disassoc::wal_get_parameter_from_cmd MAC return err_code [%u]!}\r\n", ul_ret);
        oal_free(pc_command);
        return -OAL_EINVAL;
    }
    /* 3.1  �������Ƿ����MAC���� */
    if (WLAN_MAC_ADDR_LEN * 2 != strlen(parsed_command)) { /* ����ֵ������mac��ַ��2��  */
        oam_warning_log0(0, 0, "{wal_ioctl_set_ap_sta_disassoc::invalid MAC format}\r\n");
        oal_free(pc_command);
        return -OAL_EINVAL;
    }
    oal_strtoaddr(parsed_command, mac_addr, WLAN_MAC_ADDR_LEN); /* ���ַ� ac_name ת�������� mac_add[6] */

    oam_warning_log0(0, 0, "{wal_ioctl_set_ap_sta_disassoc::Geting CMD from APP to DISASSOC!!}");
    l_ret = wal_kick_sta(net_dev, mac_addr, WLAN_MAC_ADDR_LEN);

    /* 5. �����ͷ��ڴ� */
    oal_free(pc_command);
    return l_ret;
}
#endif /* #if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION) */

/*****************************************************************************
 �� �� ��  : wal_set_mac_to_mib
 ��������  : ����wlan�ӿ�mac��ַ
 �������  : oal_net_device_stru *pst_net_dev
 �������  : ��
 �� �� ֵ  : ������
*****************************************************************************/
hi_u32 wal_set_mac_to_mib(oal_net_device_stru *netdev)
{
    hi_u32                        ret;
    wal_msg_write_stru            write_msg;
    mac_cfg_staion_id_param_stru *param = HI_NULL;

    /* ��дWID��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_STATION_ID, sizeof(mac_cfg_staion_id_param_stru));

    /* ��������������� */
    param = (mac_cfg_staion_id_param_stru *)write_msg.auc_value;
    if (memcpy_s(param->auc_station_id, WLAN_MAC_ADDR_LEN, netdev->dev_addr, WLAN_MAC_ADDR_LEN) != EOK) {
        oam_error_log0(0, 0, "{wal_set_mac_to_mib::mem safe function err!}");
        return HI_FAIL;
    }

    if (strcmp("p2p0", netdev->name) == 0) {
        param->p2p_mode = WLAN_P2P_DEV_MODE;
    }

    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_staion_id_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_set_mac_to_mib::return err code [%u]!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
/*****************************************************************************
 �� �� ��  : wal_ioctl_get_iwname
 ��������  : ������ߵ�����, ����ȷ��������չ�Ĵ���.
 �������  : pst_net_dev: ָ��net_device��ָ��
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2013��2��21��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32  wal_ioctl_get_iwname(oal_net_device_stru *netdev, oal_iw_request_info_stru *info,
                                    hi_s8* pc_name, hi_s8* pc_extra)
{
    hi_s8    ac_iwname[] = "IEEE 802.11";

    if (memcpy_s(pc_name, sizeof(ac_iwname), ac_iwname, sizeof(ac_iwname)) != EOK) {
        oam_error_log0(0, 0, "{wal_ioctl_get_iwname::mem safe function err!}");
        return HI_FAIL;
    }
    return HI_SUCCESS;
}
#endif

#ifdef _PRE_WLAN_FEATURE_P2P
/*****************************************************************************
 ��������  : ����WPS p2p��ϢԪ��

 �޸���ʷ      :
  1.��    ��   : 2014��11��26��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_ioctl_set_wps_p2p_ie(oal_net_device_stru *netdev, const hi_u8 *puc_buf, hi_u32 len,
                                en_app_ie_type_uint8 type)
{
    wal_msg_write_stru              write_msg;
    wal_msg_stru                   *rsp_msg = HI_NULL;
    oal_app_ie_stru                 wps_p2p_ie;

    if (len > WLAN_WPS_IE_MAX_SIZE) {
        oam_error_log1(0, OAM_SF_CFG, "{wal_ioctl_set_wps_p2p_ie:: wrong ul_len: [%u]!}\r\n", len);
        return HI_FAIL;
    }

    /* ��ȫ��̹���6.6����(1) �̶����ȵĽṹ������ڴ��ʼ�� */
    memset_s(&wps_p2p_ie, sizeof(oal_app_ie_stru), 0, sizeof(oal_app_ie_stru));

    switch (type) {
        case OAL_APP_BEACON_IE:
        case OAL_APP_PROBE_RSP_IE:
        case OAL_APP_ASSOC_RSP_IE:
            wps_p2p_ie.app_ie_type = type;
            wps_p2p_ie.ie_len      = len;
            if (memcpy_s(wps_p2p_ie.auc_ie, sizeof(wps_p2p_ie.auc_ie), puc_buf, len) != EOK) {
                oam_error_log0(0, OAM_SF_CFG, "{wal_ioctl_set_wps_p2p_ie::mem safe function err!}");
                return HI_FAIL;
            }
            break;
        default:
            oam_error_log1(0, OAM_SF_CFG, "{wal_ioctl_set_wps_p2p_ie:: wrong type: [%x]!}\r\n", type);
            return HI_FAIL;
    }

    if (memcpy_s(write_msg.auc_value, sizeof(write_msg.auc_value), &wps_p2p_ie, sizeof(wps_p2p_ie)) != EOK) {
        oam_error_log0(0, OAM_SF_CFG, "{wal_ioctl_set_wps_p2p_ie::mem safe function err!}");
        return HI_FAIL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_SET_WPS_P2P_IE, sizeof(wps_p2p_ie));

    /* ������Ϣ */
    hi_u32 ret = wal_send_cfg_event(netdev, WAL_MSG_TYPE_WRITE,
                                    WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(wps_p2p_ie),
                                    (hi_u8 *)&write_msg, HI_TRUE, &rsp_msg);
    if ((ret != HI_SUCCESS) || (rsp_msg == HI_NULL)) {
        oam_error_log1(0, OAM_SF_P2P, "{wal_ioctl_set_wps_p2p_ie:: wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ��ȡ���صĴ����� */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_error_log1(0, OAM_SF_P2P, "{wal_ioctl_set_wps_p2p_ie::wal_send_cfg_event return err code: [%u]!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_p2p_noa
 ��������  : ����p2p noa���ܲ���
 �������  : oal_net_device_stru *pst_net_dev
             hi_s8 *pc_paramm
 �������  : ��
 �� �� ֵ  : static hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��1��22��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

****************************************************************************/
hi_u32 wal_ioctl_set_p2p_noa(oal_net_device_stru *netdev, const mac_cfg_p2p_noa_param_stru *p2p_noa_param)
{
    wal_msg_write_stru write_msg;
    wal_msg_stru      *rsp_msg = HI_NULL;
    hi_u32             ret;

    if (p2p_noa_param != HI_NULL) {
        if (memcpy_s(write_msg.auc_value, sizeof(write_msg.auc_value),
            p2p_noa_param, sizeof(mac_cfg_p2p_noa_param_stru)) != EOK) {
            oam_error_log0(0, OAM_SF_P2P, "{wal_ioctl_set_p2p_noa::mem safe function err!}");
            return HI_FAIL;
        }
    }
    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_SET_P2P_PS_NOA, sizeof(mac_cfg_p2p_noa_param_stru));

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_p2p_noa_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);
    if ((ret != HI_SUCCESS) || (rsp_msg == HI_NULL)) {
        oam_error_log1(0, OAM_SF_P2P,
            "{wal_ioctl_set_p2p_noa:: wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ��ȡ���صĴ����� */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_error_log1(0, OAM_SF_P2P,
            "{wal_ioctl_set_p2p_noa::wal_send_cfg_event return err code:  [%d]!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_ioctl_set_p2p_ops
 ��������  : ����p2p ops���ܲ���
 �������  : oal_net_device_stru *pst_net_dev
             hi_s8 *pc_paramm
 �������  : ��
 �� �� ֵ  : static hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��1��22��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

****************************************************************************/
hi_u32 wal_ioctl_set_p2p_ops(oal_net_device_stru *netdev, const mac_cfg_p2p_ops_param_stru *p2p_ops_param)
{
    wal_msg_write_stru write_msg;
    wal_msg_stru      *rsp_msg = HI_NULL;
    hi_u32             ret;

    if (p2p_ops_param != HI_NULL) {
        if (memcpy_s(write_msg.auc_value, sizeof(write_msg.auc_value),
            p2p_ops_param, sizeof(mac_cfg_p2p_ops_param_stru)) != EOK) {
            oam_error_log0(0, OAM_SF_P2P, "{wal_ioctl_set_p2p_ops::mem safe function err!}");
            return HI_FAIL;
        }
    }
    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_SET_P2P_PS_OPS, sizeof(mac_cfg_p2p_ops_param_stru));

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_p2p_ops_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);
    if ((ret != HI_SUCCESS) || (rsp_msg == HI_NULL)) {
        oam_error_log1(0, OAM_SF_P2P,
            "{wal_ioctl_set_p2p_ops:: wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ��ȡ���صĴ����� */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_error_log1(0, OAM_SF_P2P,
            "{wal_ioctl_set_p2p_ops::wal_send_cfg_event return err code:[%u]!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}
#endif

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
/*****************************************************************************
 �� �� ��  : wal_ioctl_reduce_sar
 ��������  : ����RTS ����ֵ
 �������  : ��
 �� �� ֵ  : hi_s32

 �޸���ʷ      :
  1.��    ��   : 2015��12��17��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
static hi_u32 wal_ioctl_reduce_sar(oal_net_device_stru *netdev, hi_u8 tx_power)
{
    hi_u32                      ret;
    wal_msg_write_stru          write_msg;

    oam_warning_log1(0, 0,
        "wal_ioctl_reduce_sar::supplicant set tx_power[%d] for reduce SAR purpose.\r\n", tx_power);
    if (tx_power > 100) { /* ����100��Ч */
        oam_warning_log1(0, OAM_SF_CFG,
            "wal_ioctl_reduce_sar::reduce sar failed, reason:invalid tx_power[%d] set by supplicant!", tx_power);
        return HI_ERR_CODE_INVALID_CONFIG;
    }
    /* vapδ����ʱ��������supplicant���� */
    if (oal_net_dev_priv(netdev) == NULL) {
        oam_warning_log0(0, OAM_SF_CFG, "wal_ioctl_reduce_sar::vap not created yet, ignore the cmd!");
        return HI_ERR_WIFI_WAL_INVALID_PARAMETER;
    }
    /***************************************************************************
                                ���¼���wal�㴦��
    ***************************************************************************/
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_REDUCE_SAR, sizeof(hi_u8));
    *((hi_u8*)write_msg.auc_value) = tx_power;
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(hi_u8),
                             (hi_u8 *)&write_msg,
                             HI_FALSE,
                             HI_NULL);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_error_log1(0, 0, "wal_ioctl_reduce_sar::wal_send_cfg_event failed, error no[%u]!\r\n", ret);
        return ret;
    }
    return HI_SUCCESS;
}
#endif

/*****************************************************************************
 �� �� ��  : wal_start_vap
 �������  : oal_net_device_stru *pst_net_dev
 �������  : ��
 �� �� ֵ  : static hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��5��22��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_start_vap(oal_net_device_stru *netdev)
{
    wal_msg_write_stru      write_msg;
    hi_u32                  ret;
    wal_msg_stru           *rsp_msg = HI_NULL;
#ifdef _PRE_WLAN_FEATURE_P2P
    wlan_p2p_mode_enum_uint8 p2p_mode;
    oal_wireless_dev       *wdev = HI_NULL;
#endif

    if (oal_unlikely(netdev == HI_NULL)) {
        oam_error_log0(0, 0, "{wal_start_vap::pst_net_dev is null ptr!}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    /* ��д��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_START_VAP, sizeof(mac_cfg_start_vap_param_stru));
    ((mac_cfg_start_vap_param_stru *)write_msg.auc_value)->net_dev = netdev;
#ifdef _PRE_WLAN_FEATURE_P2P
    wdev    = netdev->ieee80211_ptr;
    p2p_mode = wal_wireless_iftype_to_mac_p2p_mode(wdev->iftype);
    if (WLAN_P2P_BUTT == p2p_mode) {
        oam_error_log0(0, 0, "{wal_start_vap::wal_wireless_iftype_to_mac_p2p_mode return BUFF}\r\n");
        return HI_FAIL;
    }
    ((mac_cfg_start_vap_param_stru *)write_msg.auc_value)->p2p_mode = p2p_mode;

    oam_warning_log1(0, 0, "{wal_start_vap::en_p2p_mode:%d}\r\n", p2p_mode);
#endif
    ((mac_cfg_start_vap_param_stru *)write_msg.auc_value)->mgmt_rate_init_flag = HI_TRUE;

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_start_vap_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_start_vap::wal_alloc_cfg_event return err code %u!}\r\n", ret);
        return ret;
    }

    /* ����������Ϣ */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(0, 0, "{wal_start_vap::hmac start vap fail, err code[%u]!}\r\n", ret);
        return ret;
    }

    if ((oal_netdevice_flags(netdev) & OAL_IFF_RUNNING) == 0) {
        oal_netdevice_flags(netdev) |= OAL_IFF_RUNNING;
    }

    /* AP/Meshģʽ,����VAP��,�������Ͷ��� */
    oal_net_tx_wake_all_queues(); /* �������Ͷ��� */

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_stop_vap
 ��������  : ͣ��vap
 �������  : oal_net_device_stru: net_device
 �������  : ��
 �� �� ֵ  : ������

 �޸���ʷ      :
  1.��    ��   : 2015��5��25��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_stop_vap(oal_net_device_stru *netdev)
{
    wal_msg_write_stru      write_msg;
    wal_msg_stru           *rsp_msg = HI_NULL;
    hi_u32                  ret;
#ifdef _PRE_WLAN_FEATURE_P2P
    wlan_p2p_mode_enum_uint8 p2p_mode;
    oal_wireless_dev   *wdev = HI_NULL;
#endif

    if (netdev == HI_NULL) {
        oam_error_log0(0, 0, "{wal_stop_vap::pst_net_dev is null ptr!}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }

    /* �������up״̬������ֱ�ӷ��سɹ�,��ֹnetdevice״̬��VAP״̬��һ�µ���� */
    if ((oal_netdevice_flags(netdev) & OAL_IFF_RUNNING) == 0) {
        /* DTS2015121600902 ���vap״̬��netdevice״̬��һ�£��޷�down vap������ */
        oam_warning_log0(0, 0, "{wal_stop_vap::vap is already down,continue to reset hmac vap state.}\r\n");
    }

    /***************************************************************************
                           ���¼���wal�㴦��
    ***************************************************************************/
    /* ��дWID��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_DOWN_VAP, sizeof(mac_cfg_down_vap_param_stru));
    ((mac_cfg_down_vap_param_stru *)write_msg.auc_value)->net_dev = netdev;
#ifdef _PRE_WLAN_FEATURE_P2P
    wdev    = netdev->ieee80211_ptr;
    p2p_mode = wal_wireless_iftype_to_mac_p2p_mode(wdev->iftype);
    if (WLAN_P2P_BUTT == p2p_mode) {
        oam_error_log0(0, 0, "{wal_stop_vap::wal_wireless_iftype_to_mac_p2p_mode return BUFF}\r\n");
        return HI_FAIL;
    }
    ((mac_cfg_start_vap_param_stru *)write_msg.auc_value)->p2p_mode = p2p_mode;

    oam_warning_log1(0, 0, "{wal_stop_vap::en_p2p_mode:%d}\r\n", p2p_mode);
#endif

    /* ������Ϣ */
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_down_vap_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);

    if (HI_SUCCESS != wal_check_and_release_msg_resp(rsp_msg)) {
        oam_warning_log0(0, 0, "wal_stop_vap::wal_check_and_release_msg_resp fail");
    }

    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(0, 0, "{wal_stop_vap::wal_alloc_cfg_event return err code %d!}\r\n", ret);
        return ret;
    }

    return HI_SUCCESS;
}

hi_u32 wal_get_vap_p2p_mode(const oal_wireless_dev *wdev,
    wlan_vap_mode_enum_uint8 *vap_mode, wlan_p2p_mode_enum_uint8 *p2p_mode)
{
    hi_unref_param(p2p_mode);

    switch (wdev->iftype) {
        case NL80211_IFTYPE_STATION:
            *vap_mode = WLAN_VAP_MODE_BSS_STA;
            break;
        case NL80211_IFTYPE_AP:
            *vap_mode = WLAN_VAP_MODE_BSS_AP;
            break;
#ifdef _PRE_WLAN_FEATURE_P2P
        case NL80211_IFTYPE_P2P_CLIENT:
            *vap_mode = WLAN_VAP_MODE_BSS_STA;
            *p2p_mode = WLAN_P2P_CL_MODE;
            break;
        case NL80211_IFTYPE_P2P_GO:
            *vap_mode = WLAN_VAP_MODE_BSS_AP;
            *p2p_mode = WLAN_P2P_GO_MODE;
            break;
        case NL80211_IFTYPE_P2P_DEVICE:
            *vap_mode = WLAN_VAP_MODE_BSS_STA;
            *p2p_mode = WLAN_P2P_DEV_MODE;
            break;
#endif
#ifdef _PRE_WLAN_FEATURE_MESH
        case NL80211_IFTYPE_MESH_POINT:
            *vap_mode = WLAN_VAP_MODE_MESH;
            break;
#endif
        default:
            oam_warning_log1(0, 0, "{wal_get_vap_p2p_mode::iftype[%d] is not supported!}", wdev->iftype);
            return HI_ERR_SUCCESS;
    }

    return HI_CONTINUE;
}

/*****************************************************************************
 �� �� ��  : wal_init_wlan_vap
 ��������  : ��ʼ��wlan0,p2p0��vap
 �������  : oal_net_device_stru *pst_cfg_net_dev
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��5��22��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_init_wlan_vap(oal_net_device_stru *netdev)
{
    wal_msg_stru             *rsp_msg = HI_NULL;
    wal_msg_write_stru        write_msg = {0};
    wlan_vap_mode_enum_uint8  vap_mode = 0;
    wlan_p2p_mode_enum_uint8  p2p_mode = WLAN_LEGACY_VAP_MODE;
    mac_vap_stru             *mac_vap = oal_net_dev_priv(netdev);

    if (mac_vap != HI_NULL) {
        oam_warning_log0(0, 0, "{wal_init_wlan_vap::pst_mac_vap is already exist}\r\n");
        return HI_SUCCESS;
    }

    oal_wireless_dev      *wdev       = oal_netdevice_wdev(netdev);
    oal_net_device_stru   *netdev_cfg = oal_get_netdev_by_name(WLAN_CFG_VAP_NAME);
    if ((wdev == HI_NULL) || (netdev_cfg == HI_NULL)) {
        oam_warning_log2(0, 0, "{wal_init_wlan_vap::wdev[%p]/netdev_cfg[%p] is null}",
            (uintptr_t)wdev, (uintptr_t)netdev_cfg);
        return HI_ERR_CODE_PTR_NULL;
    }

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
    oal_dev_put(netdev_cfg);
#endif

    /* ������WIFI��AP��ʱ����VAP */
    if (wal_get_vap_p2p_mode(wdev, &vap_mode, &p2p_mode) == HI_ERR_SUCCESS) {
        return HI_ERR_SUCCESS;
    }

    /***************************************************************************
        ���¼���wal�㴦��
    ***************************************************************************/
    /* ��д��Ϣ */
    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_ADD_VAP, sizeof(mac_cfg_add_vap_param_stru));
    ((mac_cfg_add_vap_param_stru *)write_msg.auc_value)->net_dev      = netdev;
    ((mac_cfg_add_vap_param_stru *)write_msg.auc_value)->vap_mode     = vap_mode;
    ((mac_cfg_add_vap_param_stru *)write_msg.auc_value)->cfg_vap_indx = WLAN_CFG_VAP_ID;
    ((mac_cfg_add_vap_param_stru *)write_msg.auc_value)->p2p_mode     = p2p_mode;

    hi_u32 ret = wal_send_cfg_event(netdev_cfg, WAL_MSG_TYPE_WRITE,
        WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_add_vap_param_stru), (hi_u8 *)&write_msg, HI_TRUE, &rsp_msg);
    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_warning_log1(WLAN_CFG_VAP_ID, 0, "{wal_init_wlan_vap::return err code %u!}\r\n", ret);
        return ret;
    }

    /* ��ȡ���صĴ����� */
    ret = wal_check_and_release_msg_resp(rsp_msg);
    if (ret != HI_SUCCESS) {
        oam_warning_log1(WLAN_CFG_VAP_ID, 0, "{wal_init_wlan_vap::hmac add vap fail, err code[%u]!}\r\n", ret);
        return ret;
    }

#ifdef _PRE_WLAN_FEATURE_P2P
    mac_device_stru *mac_dev = mac_res_get_dev();
    mac_vap = oal_net_dev_priv(netdev);
    if (mac_vap == HI_NULL) {
        oam_error_log0(0, 0, "{wal_init_wlan_vap::oal_net_dev_priv(pst_net_dev) is null ptr.}");
        return HI_ERR_CODE_PTR_NULL;
    }

    if (p2p_mode == WLAN_P2P_DEV_MODE) {
        mac_dev->p2p_info.p2p0_vap_idx = mac_vap->vap_id;
    }
#endif

    return HI_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : wal_deinit_wlan_vap
 ��������  : ������WIFI��AP�ر�ʱɾ��VAP
 �������  : oal_net_device_stru *pst_net_dev
 �������  : ��
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2015��1��3��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_deinit_wlan_vap(oal_net_device_stru *netdev)
{
    wal_msg_write_stru           write_msg;
    wal_msg_stru                *rsp_msg = HI_NULL;
    mac_vap_stru                *mac_vap = HI_NULL;
    hi_u32                       ret;

#ifdef _PRE_WLAN_FEATURE_P2P
    wlan_p2p_mode_enum_uint8    p2p_mode = WLAN_LEGACY_VAP_MODE;
#endif

    if (oal_unlikely(netdev == HI_NULL)) {
        oam_error_log0(0, 0, "{wal_deinit_wlan_vap::pst_del_vap_param null ptr !}\r\n");
        return HI_ERR_CODE_PTR_NULL;
    }

    mac_vap = oal_net_dev_priv(netdev);
    if (mac_vap == HI_NULL) {
        oam_warning_log0(0, 0, "{wal_deinit_wlan_vap::pst_mac_vap is already null}\r\n");
        return HI_SUCCESS;
    }

#ifdef _PRE_WLAN_FEATURE_P2P
    if (strcmp("p2p0", netdev->name) == 0) {
        p2p_mode = WLAN_P2P_DEV_MODE;
    }
    oam_warning_log1(mac_vap->vap_id, 0, "{wal_deinit_wlan_vap::en_p2p_mode:%d}\r\n", p2p_mode);
#endif

#ifdef _PRE_WLAN_FEATURE_ANY
    if (mac_vap->support_any == HI_TRUE) {
        hi_wifi_any_deinit();
    }
#endif
    /***************************************************************************
                                ���¼���wal�㴦��
    ***************************************************************************/
    /* ɾ��vap ʱ��Ҫ��������ֵ */
    ((mac_cfg_del_vap_param_stru *)write_msg.auc_value)->net_dev = netdev;
#ifdef _PRE_WLAN_FEATURE_P2P
    ((mac_cfg_del_vap_param_stru *)write_msg.auc_value)->p2p_mode = mac_vap->p2p_mode;
#endif

    wal_write_msg_hdr_init(&write_msg, WLAN_CFGID_DEL_VAP, sizeof(mac_cfg_del_vap_param_stru));
    ret = wal_send_cfg_event(netdev,
                             WAL_MSG_TYPE_WRITE,
                             WAL_MSG_WRITE_MSG_HDR_LENGTH + sizeof(mac_cfg_del_vap_param_stru),
                             (hi_u8 *)&write_msg,
                             HI_TRUE,
                             &rsp_msg);

    if (HI_SUCCESS != wal_check_and_release_msg_resp(rsp_msg)) {
        oam_warning_log0(0, 0, "wal_deinit_wlan_vap::wal_check_and_release_msg_resp fail.");
    }

    if (oal_unlikely(ret != HI_SUCCESS)) {
        oam_error_log1(mac_vap->vap_id, 0, "{wal_deinit_wlan_vap::return error code %d}\r\n", ret);
    }

    oal_net_dev_priv(netdev) = NULL;

    return ret;
}

/*****************************************************************************
 �� �� ��  : wal_get_mac_addr
 ��������  : �ж�mac��ַ�Ƿ�Ϸ�
 �������  : ��
 �������  : hi_u8 *buf
 �� �� ֵ  : hi_u32

 �޸���ʷ      :
  1.��    ��   : 2017��1��18��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���

*****************************************************************************/
hi_u32 wal_macaddr_check(const hi_u8 *mac_addr)
{
    if ((HI_TRUE == mac_addr_is_zero(mac_addr)) || ((mac_addr[0] & 0x1) == 0x1)) {
        return HI_FAIL;
    }

    return HI_SUCCESS;
}


/*****************************************************************************
 ��������  : wal��ͨ��change virtual iftype����vap�Ľӿ�
 �޸���ʷ      :
  1.��    ��   : 2015��12��2��
    ��    ��   : Hisilicon
    �޸�����   : �����ɺ���
  2.    ��    ��   : 2019��2��12��
    ��    ��   : Hisilicon
    �޸�����   : �޸ĺ�����Ϊwal_setup_vap����iftype��ֵ�Ƶ�������

*****************************************************************************/
#if (_PRE_OS_VERSION_LITEOS == _PRE_OS_VERSION)
hi_u32  wal_setup_vap(oal_net_device_stru *netdev)
{
    hi_u32 ret = HI_FAIL;
    struct netif *netif = HI_NULL;

    if (oal_netdevice_flags(netdev) & OAL_IFF_RUNNING) {
        /* �л���Meshǰ��������豸����UP״̬����Ҫ��down �����豸 */
        hi_diag_log_msg_i0(0, "wal_setup_vap:stop netdevice.");
        wal_netdev_stop(netdev);

        ret = wal_deinit_wlan_vap(netdev);
        if (ret != HI_SUCCESS) {
            hi_diag_log_msg_i0(0, "wal_setup_vap:wlan_deinit_wlan_vap failed");
            return ret;
        }
    }

    netif = netif_find((const hi_char *)netdev->name);
    if (netif != HI_NULL) {
        /* ����IPv6 linklocal address(SLAAC) */
        if ((netdev->ieee80211_ptr->iftype == NL80211_IFTYPE_AP) ||
            (netdev->ieee80211_ptr->iftype == NL80211_IFTYPE_MESH_POINT)) {
#ifdef _PRE_WLAN_FEATURE_LWIP_IPV6_AUTOCONFIG
            (hi_void)netifapi_set_ip6_autoconfig_disabled(netdev->lwip_netif);
            (hi_void)netifapi_set_accept_ra(netif, HI_FALSE);
            (hi_void)netifapi_set_ipv6_forwarding(netif, HI_TRUE);
            (hi_void)netifapi_set_ra_enable(netif, HI_TRUE);
#endif
            (hi_void)netifapi_netif_add_ip6_linklocal_address(netif, HI_TRUE);
        }
    }

    ret = wal_init_wlan_vap(netdev);

    return ret;
}
#elif (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
hi_u32  wal_setup_vap(oal_net_device_stru *net_dev)
{
    hi_u32 ret = HI_FAIL;

    if (oal_netdevice_flags(net_dev) & OAL_IFF_RUNNING) {
        /* �л���Meshǰ��������豸����UP״̬����Ҫ��down �����豸 */
        hi_diag_log_msg_i0(0, "wal_setup_vap:stop netdevice.");
        wal_netdev_stop(net_dev);

        ret = wal_deinit_wlan_vap(net_dev);
        if (ret != HI_SUCCESS) {
            hi_diag_log_msg_i0(0, "wal_setup_vap:wlan_deinit_wlan_vap failed");
            return ret;
        }
    }

    ret = wal_init_wlan_vap(net_dev);

    return ret;
}
#endif

#if (_PRE_OS_VERSION_LINUX == _PRE_OS_VERSION)
/*****************************************************************************
 ��������  : P2P������ִ��
 �� �� ֵ  : ͳ�ƽ��ָ��
*****************************************************************************/
#ifdef _PRE_WLAN_FEATURE_P2P
hi_u32 wal_android_p2p_cmd_exec(oal_net_device_stru *netdev, hi_u8 *puc_command, hi_u32 len)
{
    if (memcmp(puc_command, CMD_P2P_SET_NOA, strlen(CMD_P2P_SET_NOA)) == 0) {
        hi_u32 skip = strlen(CMD_P2P_SET_NOA) + 1;
        mac_cfg_p2p_noa_param_stru  p2p_noa_param;
        if ((skip + sizeof(p2p_noa_param)) > len) {
            oam_error_log2(0, 0, "{wal_android_priv_cmd_exec::CMD_P2P_SET_NOA param len is [%d], need %d.}",
                len, skip + sizeof(p2p_noa_param));
            return HI_FAIL;
        }
        if (memcpy_s(&p2p_noa_param, sizeof(mac_cfg_p2p_noa_param_stru),
            puc_command + skip, sizeof(mac_cfg_p2p_noa_param_stru)) != EOK) {
            oam_error_log0(0, 0, "wal_android_priv_cmd_exec: copy noa param failed!");
            return HI_FAIL;
        }
        return wal_ioctl_set_p2p_noa(netdev, &p2p_noa_param);
    } else if (memcmp(puc_command, CMD_P2P_SET_PS, strlen(CMD_P2P_SET_PS)) == 0) {
        hi_u32 skip = strlen(CMD_P2P_SET_PS) + 1;
        mac_cfg_p2p_ops_param_stru  p2p_ops_param;
        if ((skip + sizeof(p2p_ops_param)) > len) {
            oam_error_log2(0, 0, "{wal_android_priv_cmd_exec::CMD_P2P_SET_PS param len is %d, need %d.}",
                len, skip + sizeof(p2p_ops_param));
            return HI_FAIL;
        }
        if (memcpy_s(&p2p_ops_param, sizeof(mac_cfg_p2p_ops_param_stru),
            puc_command + skip, sizeof(mac_cfg_p2p_ops_param_stru)) != EOK) {
            oam_error_log0(0, 0, "wal_android_priv_cmd_exec: copy ops param failed!");
            return HI_FAIL;
        }
        return wal_ioctl_set_p2p_ops(netdev, &p2p_ops_param);
    }
    return HI_SUCCESS;
}
#endif

/*****************************************************************************
 ��������  : ����������ִ�ж�Ӧ������
 �������  : net deviceָ��
 �� �� ֵ  : ͳ�ƽ��ָ��
*****************************************************************************/
hi_u32 wal_android_priv_cmd_exec(oal_net_device_stru *netdev, hi_u8 *puc_command, hi_u32 len)
{
    if (memcmp(puc_command, CMD_COUNTRY, strlen(CMD_COUNTRY)) == 0) {
        const hi_s8 *country_code = HI_NULL;
        hi_s8        auc_country_code[MAC_CONTRY_CODE_LEN] = {0}; /* 3: Ԫ�ظ��� */

        /* ��ʽ:COUNTRY CN */
        if (len < (strlen((hi_s8 *)CMD_COUNTRY) + 3)) { /* 3: ƫ���� */
            oam_warning_log0(0, 0, "{wal_android_priv_cmd_exec::country cn len error.}");
            return HI_FAIL;
        }
        country_code = (hi_char *)puc_command + strlen((hi_char *)CMD_COUNTRY) + 1;
        if (memcpy_s(auc_country_code, sizeof(auc_country_code), country_code, 2) != EOK) { /* ���Ƴ���Ϊ2 */
            oam_error_log0(0, 0, "wal_android_priv_cmd_exec: copy country code failed!");
            return HI_FAIL;
        }
        return wal_regdomain_update(netdev, auc_country_code, MAC_CONTRY_CODE_LEN);
#ifdef _PRE_WLAN_FEATURE_P2P
    } else if (memcmp(puc_command, CMD_SET_AP_WPS_P2P_IE, strlen(CMD_SET_AP_WPS_P2P_IE)) == 0) {
        hi_u32 skip = strlen(CMD_SET_AP_WPS_P2P_IE) + 1;
        /* �ṹ������ */
        oal_app_ie_stru *wps_p2p_ie = (oal_app_ie_stru *)(puc_command + skip);
        return wal_ioctl_set_wps_p2p_ie(netdev, wps_p2p_ie->auc_ie, wps_p2p_ie->ie_len, wps_p2p_ie->app_ie_type);
#endif
    } else if (memcmp(puc_command, CMD_TX_POWER, strlen(CMD_TX_POWER)) == 0) {
        hi_u32  skip_length = strlen((hi_char *)CMD_TX_POWER) + 1;
        hi_u8   txpwr = (hi_u8)oal_atoi((hi_char*)puc_command + skip_length);
        if (wal_ioctl_reduce_sar(netdev, txpwr) != HI_SUCCESS) {
            oam_warning_log0(0, 0, "{wal_android_priv_cmd_exec::return err code [%u]!}");
            /* ������ӡ�����룬���سɹ�����ֹsupplicant �ۼ�4�� ioctlʧ�ܵ���wifi�쳣���� */
            return HI_SUCCESS;
        }
    }
#ifdef _PRE_WLAN_FEATURE_P2P
    /* p2p�����������ִ�� */
    return wal_android_p2p_cmd_exec(netdev, puc_command, len);
#endif
    return HI_SUCCESS;
}
/*****************************************************************************
 ��������  : ˽�нӿں���
 �������  : net deviceָ��
 �� �� ֵ  : ͳ�ƽ��ָ��
*****************************************************************************/
hi_u32 wal_android_priv_cmd(oal_net_device_stru *netdev, oal_ifreq_stru *ifr, hi_s32 cmd)
{
    wal_android_wifi_priv_cmd_stru  priv_cmd    = {0};
    hi_u8                          *puc_command    = HI_NULL;
    hi_u32                          ret;

    if (ifr->ifr_data == HI_NULL) {
        return HI_FAIL;
    }
    if (oal_copy_from_user((hi_u8 *)&priv_cmd, sizeof(wal_android_wifi_priv_cmd_stru),
        ifr->ifr_data, sizeof(wal_android_wifi_priv_cmd_stru)) != 0) {
        return HI_FAIL;
    }

    if ((priv_cmd.l_total_len > MAX_PRIV_CMD_SIZE) || (priv_cmd.l_total_len < 0)) {
        oam_error_log1(0, 0, "{wal_android_priv_cmd::priavte command len:%d too long}", priv_cmd.l_total_len);
        return HI_FAIL;
    }

    /* �����ڴ汣��wpa_supplicant �·������������ */
    puc_command = oal_memalloc((hi_u32)(priv_cmd.l_total_len + 1)); /* total len Ϊpriv cmd ����buffer ���� */
    if (puc_command == HI_NULL) {
        oam_error_log0(0, 0, "{wal_android_priv_cmd::mem alloc failed.}");
        return HI_FAIL;
    }
    /* ����wpa_supplicant ����ں�̬�� */
    if (memset_s(puc_command, (hi_u32)(priv_cmd.l_total_len + 1), 0, (hi_u32)(priv_cmd.l_total_len + 1)) != EOK) {
        oam_error_log0(0, 0, "wal_android_priv_cmd: mem safe function err!");
        oal_free(puc_command);
        return HI_FAIL;
    }
    ret = oal_copy_from_user(puc_command, (hi_u32)(priv_cmd.l_total_len), ((hi_u8*)ifr->ifr_data) + 8, /* ����ƫ����8 */
        (hi_u32)(priv_cmd.l_total_len));
    if (ret != 0) {
        oam_error_log1(0, 0, "{wal_android_priv_cmd::oal_copy_from_user: err code [%u] }", ret);
        oal_free(puc_command);
        return ret;
    }
    puc_command[priv_cmd.l_total_len] = '\0';
    oam_warning_log4(0, 0, "{wal_android_priv_cmd:: private cmd total_len:%d, used_len:%d, CMD:0x%x %x}",
        priv_cmd.l_total_len, priv_cmd.l_used_len, *((hi_u32*)puc_command), *((hi_u32*)(puc_command + 4))); /* 4ƫ�� */

    /* ִ�������� */
    ret = wal_android_priv_cmd_exec(netdev, puc_command, (hi_u32)priv_cmd.l_total_len);
    oal_free(puc_command);
    return ret;
}
#endif

#ifdef __cplusplus
#if __cplusplus
    }
#endif
#endif

