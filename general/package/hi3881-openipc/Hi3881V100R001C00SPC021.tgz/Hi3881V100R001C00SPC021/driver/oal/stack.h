/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2018-2020. All rights reserved.
 * Description: stack.h
 * Author: Hisilicon
 * Create: 2018-08-04
 */

#ifndef __STACK_H__
#define __STACK_H__

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/*****************************************************************************
  1 Other Header File Including
*****************************************************************************/
/*****************************************************************************
  2 Macro Definition
*****************************************************************************/
#define VECTOR_NUMBER           48
/* ROM for code 16k */
#define ROM_BASEADDR            0x00000000
#define ROM_LEN                 0x00059000      /* 1131C-debug */
#define ROM_MPU_LEN             0x00080000      /* ROM_LEN����ȡ2�������η���) */

#define PATCH_TAB_BASEADDR      0x00100000      /* RAMx2 0/1 belong to CPU_RAM */

#define PATCH_FP_MAX_NUM        256
#define PATCH_FP_REG_SIZE       4
#define PATCH_HEAD_SIZE         (PATCH_FP_MAX_NUM * PATCH_FP_REG_SIZE * 2)

#define PATCH_BASEADDR          RAM_BASEADDR

#define RAM_VECTOR_LEN          (VECTOR_NUMBER * 4)

/* the following region will not be downloaded from host */
#define RAM_NODL_DATA_LEN       0x3000

/* stack for normal */
#define USER_STACK_BASEADDR     (RAM_BASEADDR + RAM_LEN - RAM_NODL_DATA_LEN)
#define USER_STACK_LEN          0x1800

#define RAM_NODL_DATA_BASEADDR  USER_STACK_BASEADDR
#define RAM_VECTOR_BASEADDR     RAM_NODL_DATA_BASEADDR

#define PKT_H_RAM_BASEADDR      0x30400000
#define PKT_H_RAM_LEN           0x00006000

#define PKT_B_RAM_BASEADDR      0x40100000

#define PSM_SAVE_BASEADDR       0x4011C000
#define PSM_SAVE_PHY_OFFSET     0x400

/* PKT A ���͵�ַ�ռ���Ҫ�ٹ滮 */
#ifdef SW_DEBUG
#define OML_DATA_BUFF_LEN       0x00000C00         /* 3k */
#else
#define OML_DATA_BUFF_LEN       4
#endif
#define OML_DATA_BUFF_ADDR      (PKT_B_RAM_BASEADDR + PKT_B_RAM_LEN - OML_DATA_BUFF_LEN)

/* ��������ʱ��һ��slave�ڵĻ���ַӦ����0x3000_0000��
   ��ʵ�ʴ��������Ϊ��0x0300_0000,����MPU����0x2000_0000~0x2FFF_FFFF ��ַ����д */
#define ROM_PROTECT_BASEADDR    0x20000000
#define ROM_PROTECT_LEN         0x10000000

/* ����Ϊ��ҪMPU������RAM�ռ䣬����������ⲿ�ֿռ䣬����д��������޸������ռ������ */
#define ROM_PROTECT_BASEADDR_1  0x200000
#define ROM_PROTECT_LEN_1       0x200000

#define ROM_PROTECT_BASEADDR_2  0x30200000
#define ROM_PROTECT_LEN_2       0x100000

#define ROM_PROTECT_BASEADDR_3  0x30500000
#define ROM_PROTECT_LEN_3       0x100000

#define ROM_PROTECT_BASEADDR_4  0x30600000
#define ROM_PROTECT_LEN_4       0x100000

/*****************************************************************************
  3 Enum Type Definition
*****************************************************************************/
/*****************************************************************************
  4 Global Variable Declaring
*****************************************************************************/
/*****************************************************************************
  5 Message Header Definition
*****************************************************************************/
/*****************************************************************************
  6 Message Definition
*****************************************************************************/
/*****************************************************************************
  7 STRUCT Type Definition
*****************************************************************************/
/*****************************************************************************
  8 UNION Type Definition
*****************************************************************************/
/*****************************************************************************
  9 OTHERS Definition
*****************************************************************************/
/*****************************************************************************
  10 Function Declare
*****************************************************************************/
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* end of stack_r4.h */

