/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2018-2020. All rights reserved.
 * Description: Header file for oal_main.c.
 * Author: Hisilicon
 * Create: 2018-08-04
 */

#ifndef __OAL_MAIN_H__
#define __OAL_MAIN_H__

/*****************************************************************************
  1 ����ͷ�ļ�����
*****************************************************************************/
#include "oal_ext_if.h"
#include "oal_err_wifi.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#ifdef __cplusplus
#if __cplusplus
    }
#endif
#endif

#endif /* end of oal_main */
