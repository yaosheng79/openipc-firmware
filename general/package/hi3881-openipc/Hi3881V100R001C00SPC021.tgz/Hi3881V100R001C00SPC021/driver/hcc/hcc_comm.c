/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2018-2020. All rights reserved.
 * Description: hcc_comm.c
 * Author: Hisilicon
 * Create: 2018-08-04
 */

#ifndef __HCC_COMM_H
#define __HCC_COMM_H

#include "hi_types_base.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/*****************************************************************************
  1 ȫ�ֱ�������
*****************************************************************************/
hi_u8  g_sdio_txpkt_index = 0;   /* ����֡��� */

#ifdef __cplusplus
#if __cplusplus
    }
#endif
#endif

#endif
